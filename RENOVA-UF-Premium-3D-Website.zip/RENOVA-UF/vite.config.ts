import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), 'VITE_');
  for (const [name, value] of Object.entries(env)) {
    if (
      /SECRET|PRIVATE|SERVICE_ROLE/i.test(name) ||
      /^(sb_secret_|sk_live_|sk_test_|whsec_)/.test(value)
    )
      throw new Error(`Server-only credential in browser environment: ${name}`);
    if (name === 'VITE_SUPABASE_PUBLISHABLE_KEY' && value.startsWith('eyJ')) {
      try {
        const payload = JSON.parse(Buffer.from(value.split('.')[1], 'base64url').toString());
        if (payload.role !== 'anon') throw new Error('Unsafe Supabase key');
      } catch {
        throw new Error(
          'Use a Supabase publishable key or legacy anon key, never a service role key.',
        );
      }
    }
  }
  return {
    plugins: [react(), tailwindcss()],
    build: {
      target: 'es2022',
      sourcemap: false,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules/three/') || id.includes('node_modules/@react-three/'))
              return 'three';
            if (id.includes('node_modules/@supabase/')) return 'supabase';
          },
        },
      },
    },
  };
});
