import assert from 'node:assert/strict';
import worker from '../.check/functions/index.js';
const env = {
  ASSETS: {
    fetch: () => new Response('<html>SPA</html>', { headers: { 'Content-Type': 'text/html' } }),
  },
};
const ctx = { waitUntil() {}, passThroughOnException() {} };
async function request(path, method = 'GET', body) {
  return worker.fetch(
    new Request(`https://renova.example${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
    }),
    env,
    ctx,
  );
}
const config = await request('/api/config');
assert.equal(config.status, 200);
assert.deepEqual(await config.json(), {
  checkoutEnabled: false,
  contactEnabled: false,
  turnstileSiteKey: null,
});
const unknown = await request('/api/not-a-route');
assert.equal(unknown.status, 404);
assert.match(unknown.headers.get('Content-Type'), /application\/json/);
for (const endpoint of ['/api/contact', '/api/checkout']) {
  assert.equal((await request(endpoint, 'POST', {})).status, 503);
  assert.equal((await request(endpoint)).status, 405);
}
assert.equal((await request('/api/admin/upload', 'POST', {})).status, 503);
const page = await request('/mobler');
assert.equal(await page.text(), '<html>SPA</html>');
console.log(
  'Compiled Pages Functions: config, unknown API, contact, checkout, admin upload, method guards and static fallback passed.',
);
