/** Run locally after migration. Values are read from the shell, never written to disk. */
import { createClient } from '@supabase/supabase-js';
const { SUPABASE_URL, SUPABASE_SECRET_KEY } = process.env;
if (!SUPABASE_URL?.startsWith('https://') || !SUPABASE_SECRET_KEY) {
  throw new Error('Set SUPABASE_URL and SUPABASE_SECRET_KEY in the shell first.');
}
const db = createClient(SUPABASE_URL, SUPABASE_SECRET_KEY, { auth: { persistSession: false } });
for (const [id, options] of [
  ['furniture-images', { public: true, fileSizeLimit: 8 * 1024 * 1024, allowedMimeTypes: ['image/jpeg','image/png','image/webp'] }],
  ['furniture-models', { public: true, fileSizeLimit: 20 * 1024 * 1024, allowedMimeTypes: ['model/gltf-binary'] }],
]) {
  const existing = await db.storage.getBucket(id);
  const result = existing.data ? await db.storage.updateBucket(id, options) : await db.storage.createBucket(id, options);
  if (result.error) throw new Error(`Bucket ${id} could not be configured. Check project permissions.`);
  console.log(`Configured ${id}.`);
}
