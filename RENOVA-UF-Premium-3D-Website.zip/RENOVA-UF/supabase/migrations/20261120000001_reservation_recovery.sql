-- Only the server may call this after fully enumerating Stripe Sessions and finding no match.
begin;
create function public.release_unattached_order(p_order_id uuid) returns void
language plpgsql security invoker set search_path = '' as $$
declare current_order public.orders%rowtype; item record;
begin
  select * into strict current_order from public.orders where id=p_order_id for update;
  if current_order.status='cancelled' then return; end if;
  if current_order.status <> 'creating' or current_order.stripe_session_id is not null
    or current_order.created_at > now() - interval '45 minutes' then raise exception 'UNSAFE_RELEASE'; end if;
  update public.orders set status='cancelled',updated_at=now() where id=p_order_id;
  for item in select product_id,quantity from public.order_items where order_id=p_order_id order by product_id loop
    perform 1 from public.products where id=item.product_id for update;
    update public.products set stock=stock+item.quantity,availability='available' where id=item.product_id;
  end loop;
end; $$;
revoke all on function public.release_unattached_order(uuid) from public, anon, authenticated;
grant execute on function public.release_unattached_order(uuid) to service_role;
commit;
