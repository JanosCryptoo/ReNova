# Payments and inventory

Payments are optional and **off by default**. The included integration creates hosted Stripe Checkout Sessions from database prices. It does not collect card details in this site's own forms. No live account, live charge or production webhook was configured while building this source package.

## Required Cloudflare Pages runtime settings

Configure these in the Cloudflare Pages project's **runtime** environment. Redeploy after changing settings. Only the two `VITE_SUPABASE_*` variables belong in the browser build.

| Name                    | Purpose                                                                                                  |
| ----------------------- | -------------------------------------------------------------------------------------------------------- |
| `SUPABASE_URL`          | Same project as the frontend                                                                             |
| `SUPABASE_SECRET_KEY`   | Server-only Supabase secret/service key                                                                  |
| `SITE_URL`              | Exact HTTPS site origin used for origin checks and payment redirects                                     |
| `TURNSTILE_SITE_KEY`    | Public Turnstile widget key                                                                              |
| `TURNSTILE_SECRET_KEY`  | Server-only verification key                                                                             |
| `STRIPE_SECRET_KEY`     | Begin with a Stripe **test** secret key                                                                  |
| `STRIPE_WEBHOOK_SECRET` | Signing secret for this deployment's webhook endpoint                                                    |
| `ORDER_TOKEN_SECRET`    | A cryptographically random secret of at least 32 characters; keep stable to preserve guest receipt links |
| `CHECKOUT_ENABLED`      | Set exactly `true` after database, webhook and store content setup                                       |
| `ALLOW_LIVE_PAYMENTS`   | Leave false/blank in tests; exact `true` is additionally required for a live key                         |
| `STRIPE_ENABLE_SWISH`   | Optional exact `true`, only after Stripe confirms account eligibility and the method is enabled          |

To generate an order token secret locally, use a trusted password generator or `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"` and paste it into the Cloudflare secret field. Do not commit it.

The Stripe SDK uses its fetch HTTP client and Web Crypto signature provider for the Cloudflare runtime. The integration permits card payments by default. It does not automatically enable every method in the Stripe dashboard. Optional Swish is explicitly requested only when configured; account and customer eligibility still determine availability. Keep preview environments on separate test credentials and databases.

## Webhook setup

Create a Stripe webhook destination pointing to:

```text
https://YOUR-SITE/api/stripe-webhook
```

Subscribe to:

- `checkout.session.completed`
- `checkout.session.async_payment_succeeded`
- `checkout.session.async_payment_failed`
- `checkout.session.expired`

Use the endpoint's own signing secret; Stripe CLI forwarding has a different secret. Verification uses the **original raw body**, the signature header, Web Crypto and the SDK's timestamp tolerance. Store/test keys and webhook mode must match. A return-page URL is never accepted as proof of payment.

## Transaction protocol

1. The browser sends only product IDs, integer quantities, name, email, a stable random `requestId`, and a fresh Turnstile token. Prices in the browser are display-only.
2. `reserve_order` locks product rows in deterministic ID order and reads prices and published availability from Postgres. It creates order/item snapshots and decrements available stock in one transaction. A unique piece becomes reserved before any Stripe request is sent. Another checkout cannot reserve the same unit.
3. The request ID is the order ID and Stripe idempotency key. The database stores a fingerprint of the sorted cart and customer details; reusing an ID for changed input is rejected. Keep the request ID for a retry after a network failure.
4. Stripe gets only server-derived SEK line totals. The session expiry is fixed at 40 minutes after reservation creation. A new creation attempt is refused after approximately 10 minutes, preserving Stripe's minimum 30-minute expiry requirement. Retries reuse the exact same expiration and idempotency key. Changes in payment-method settings should wait until active reservations have settled.
5. The verified webhook checks the session/order relationship, mode, currency and exact amount. A single database transaction records the event and changes order/inventory state. Duplicate events do nothing. Paid is terminal: a later stale failure or expiry cannot restock a sold item.
6. A completed but unpaid session becomes `payment_pending` and **keeps stock reserved** until an asynchronous success/failure is verified. A local elapsed timer never frees stock.
7. Expiration/failure restores stock once. Cancellation retrieves and expires the real Stripe Session first; a concurrent successful payment wins. Returning from Stripe without paying does not by itself release a reservation.

Guest receipt links carry a signed opaque token. The status endpoint returns only status, total and currency; it never returns customer data. Tokens also authorize explicit cancellation of that order. Keep them private. Token secret rotation invalidates old receipt/cancellation links. The admin can still view orders.

The current checkout is for **pickup in Eskilstuna by arrangement**. No shipping charge is added and no delivery address is collected. Review prices, any tax treatment, consumer-facing terms and actual pickup details before activation. Stripe email receipts are controlled in your Stripe dashboard; enable and test them. The website provides its own verified status page, but does not send email itself.

## Failure recovery

An external request can succeed while its local response is lost. The safe response is to keep inventory reserved rather than risk selling the same piece twice. The admin dashboard includes **Kontrollera reservation**, which calls an authenticated `/api/admin/reconcile` endpoint:

- If a Session exists, it retrieves authoritative Stripe status and repairs the order. An open Session is only expired after its intended expiry. Paid status is never derived from a browser claim.
- If the database has no Session ID, wait at least 45 minutes. The endpoint exhaustively enumerates Sessions created around that order's possible creation window and matches metadata/reference IDs. If enumeration is incomplete or multiple matches exist, it stops and keeps stock reserved.
- Only when enumeration proves there is no Session may it release an unattached reservation. This is admin-only and checked again under an order lock.
- For a completed unpaid Session, it keeps the reservation unless the payment is paid, a verified async failure arrives, or the retrieved PaymentIntent is canceled. If Stripe remains processing, wait or contact Stripe support; do not manually restock.

Monitor failed Stripe deliveries and replay them after repairing configuration. A database error returns non-2xx so Stripe retries. In a prolonged outage, use the admin reconciliation control and the Stripe dashboard. The code does not perform refunds automatically. Handle refunds in Stripe and agree whether the physical item should be relisted; no automatic restocking on refund events is included.

## Mandatory account-connected tests before live activation

Use genuine test fixtures in a **test project**, then remove them. Record the actual results separately; these require your credentials and were not performed on a live account during source creation.

1. Confirm catalog publication, admin authorization, upload limits, role removal and RLS with anonymous and non-admin sessions.
2. Use two private browser sessions to buy the same stock-one fixture concurrently. Exactly one reservation must succeed; the other must get 409. Verify the second session does not reach payment.
3. Alter a browser-submitted total/price. Stripe must still receive the database price. Alter IDs, quantities, Origin and request bodies and verify rejections.
4. Complete a test card payment. Observe the signed webhook, one paid order, one payment reference and zero stock. Visit the return URL before the webhook arrives: it must say pending, not paid.
5. Replay the same webhook, then deliver stale pending/expiry events after a paid event. Stock and totals must remain unchanged. Tampered signatures/bodies must return 400.
6. Abandon checkout, let the Stripe session expire and verify one restock. Cancel while another tab completes payment; the piece must never become available after successful payment.
7. Exercise webhook outages, creation-response loss and admin reconciliation. Never free inventory only because a timer passed.
8. Test failed and asynchronous payments, including supported Swish test flows if enabled. Confirm stock stays reserved while payment is pending.
9. Verify receipt email settings, Swedish checkout wording, pickup instructions, terms, privacy, real product photos and all customer support details.
10. Only after passing the above, use a live eligible business account, set live webhook secrets, explicitly set `ALLOW_LIVE_PAYMENTS=true`, and perform a controlled real transaction/refund with the owner.

## Primary references checked

- [Stripe limited inventory and Session expiry](https://docs.stripe.com/payments/checkout/managing-limited-inventory)
- [Stripe fulfillment](https://docs.stripe.com/checkout/fulfillment)
- [Stripe webhook verification and retries](https://docs.stripe.com/events/manage-webhook-endpoints)
- [Stripe idempotent requests](https://docs.stripe.com/api/idempotent_requests)
- [Stripe Swish](https://docs.stripe.com/payments/swish)
- [Cloudflare Pages Functions routing](https://developers.cloudflare.com/pages/functions/routing/)
