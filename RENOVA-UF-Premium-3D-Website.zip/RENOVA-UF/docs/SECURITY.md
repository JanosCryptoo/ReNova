# Security and backend setup

The static showroom works with no account, keys or database. Admin writes, contact storage and payments remain disabled until their services are configured. No demonstration customer records, invented inventory or shared admin password are included.

## Configure Supabase

1. Create a Supabase project in the region you intend to use. Keep preview and production projects separate.
2. Run the SQL files in `supabase/migrations/` in filename order in the project's SQL Editor. These migrations target a **new project**, not an existing unrelated database. They create explicit table grants, foreign keys, checks, indexes and RLS policies.
3. Set these public build variables in Cloudflare Pages: `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`. A publishable key is intentionally public. Never substitute a service-role or secret key.
4. Set server-only Pages variables/secrets `SUPABASE_URL`, `SUPABASE_SECRET_KEY` and `SITE_URL`. The server URL and browser URL must identify the same project. `SITE_URL` is the site's exact HTTPS origin, such as your final Pages address or custom domain. Preview deployments need their own correct origin and isolated credentials.
5. Create the image/model buckets by running `node supabase/storage-setup.mjs` from a trusted local shell with the two server Supabase variables temporarily set in its environment. The script creates or updates only the two named buckets. Do not put the secret key in a browser, screenshot, command argument, committed file or `VITE_` variable. Alternatively create the buckets in the Supabase dashboard using the limits below.
6. Create each intended admin in Supabase Auth. Configure the Auth Site URL and allowed redirect URLs. For this small private team, disable public account signups. Add only intended users to the role table using SQL Editor:

   ```sql
   insert into public.admin_roles (user_id, role)
   values ('REPLACE-WITH-THE-AUTH-USER-UUID', 'admin');
   ```

7. Redeploy, sign in at `/admin`, upload a real photograph and create an unpublished product. Publish it, reload in a private browser, then edit it and verify the persisted change. Test a normal non-admin Auth user too: it must not list orders, read contacts, create roles, upload or change products. Run Supabase's security advisors before launch.

## Access boundaries

| Data                                                  | Visitor                                       | Signed-in non-admin | Admin                |
| ----------------------------------------------------- | --------------------------------------------- | ------------------- | -------------------- |
| Published products/photos/restorations/company photos | Read                                          | Read                | Read and manage      |
| Draft content                                         | None                                          | None                | Read and manage      |
| Admin role                                            | None                                          | Read own role only  | Read own role only   |
| Orders, line items, contacts                          | None                                          | None                | Read                 |
| Order status from Pages API                           | Valid opaque receipt token, status/total only | Same                | Same                 |
| Reservation and payment RPCs                          | None                                          | None                | None through browser |

Only Pages Functions use the Supabase secret to call payment transactions. A database `private.is_admin()` helper checks the role table against `auth.uid()`; mutable `user_metadata` is never an authorization source. The helper has a fixed empty search path. It returns a boolean only, and the `private` schema must **not** be exposed in the Data API. Transaction RPCs use `SECURITY INVOKER`, revoke default public execution and grant execution only to `service_role`. Browser UI checks are convenience; RLS and server verification enforce access.

Revoking an admin role immediately blocks subsequent role-checked mutations even if an old Auth token still exists. Revoke active sessions as well when removing access. Use strong individual passwords and Supabase MFA where appropriate. This package does not provide password recovery UI; manage account recovery through Supabase until one is configured.

## File upload controls

Upload uses `/api/admin/upload`, a bearer token verified with Supabase `getUser`, a fresh role lookup, and a same-origin check. Bodies are stream-limited before multipart parsing. The server checks magic bytes, size and file structure and generates the storage filename. The browser also checks image decode/dimensions and file size before sending it.

| Bucket             | Public downloads | Types           | Maximum |
| ------------------ | ---------------- | --------------- | ------- |
| `furniture-images` | Yes              | JPEG, PNG, WebP | 8 MiB   |
| `furniture-models` | Yes              | GLB 2.0         | 20 MiB  |

GLB files must be self-contained: any `uri` property is rejected, including external textures and data URIs. SVG and HTML are not accepted. Browser users have no direct INSERT/UPDATE storage policy, so they cannot bypass the upload endpoint. Admin-only storage deletion is allowed. Objects use an admin UUID directory plus a random filename and are never overwritten.

Public buckets are intended for **non-sensitive marketing assets**. An unpublished record hides its database listing; someone who already knows a public asset URL can still download the file. Never upload private customer documents or private team photos. Files are not malware-scanned or fully mesh-validated on the server; only trusted admins can upload. Use compressed, reviewed models and test rendering before publication. Asset deletion is separate from deleting a product to avoid removing reused files; clean unused assets through the Storage dashboard after checking references.

## Forms and abuse protection

Contact submissions go to `contact_messages`, visible only to admins. No email is sent automatically and the UI confirms database storage only. Activate by setting `TURNSTILE_SITE_KEY` and server secret `TURNSTILE_SECRET_KEY`, registering the exact hostname in Turnstile, and configuring the Supabase server variables above. The frontend fetches the public widget key from `/api/config`. The server verifies every token with Cloudflare and checks its hostname. Checkout also requires a token to reduce automated stock reservation abuse. Add Cloudflare WAF/rate limiting suitable for expected traffic before enabling a public store.

JSON bodies are capped at 16 KiB, contact field lengths are bounded, quantities and UUIDs are validated, and every state-changing browser API requires the configured `Origin`. API errors do not return raw upstream errors or secrets. API responses use `no-store`; order receipt URLs should never be sent to analytics. The application uses a no-referrer policy. Keep logs limited to event names and paths, and restrict Cloudflare/Supabase dashboard access.

## Operational responsibilities

The owner must complete genuine product data, pickup arrangements, public business contact details, sale terms and privacy information before taking real orders. Establish data retention, backups, customer deletion/requests, and payment/refund operations appropriate to the business. Keep dependencies updated and review security advisories. This project does not automate refunds, delivery, accounting or retention deletion.

`docs/PAYMENTS.md` explains the inventory protocol, required activation settings and test checklist. Local tests do not replace testing the configured deployment and RLS against the real Supabase project.

## Primary references checked

- [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Securing the Data API](https://supabase.com/docs/guides/api/securing-your-api)
- [Storage access control](https://supabase.com/docs/guides/storage/security/access-control)
- [Storage bucket restrictions](https://supabase.com/docs/guides/storage/buckets/creating-buckets)
- [Supabase changelog](https://supabase.com/changelog)
- [Cloudflare Pages Functions TypeScript](https://developers.cloudflare.com/pages/functions/typescript/)
- [Turnstile server validation](https://developers.cloudflare.com/turnstile/get-started/server-side-validation/)
