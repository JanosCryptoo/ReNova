# Asset provenance and licenses

## Brand and factual content

The name RENOVA UF, slogan “Från gammalt till nytt.”, Eskilstuna location, JENSEN Gymnasium Eskilstuna connection, business description, Instagram address and four brand colors came from the supplied master prompt. No team members, sales statistics, customer testimonials or completed restoration projects were invented.

The exact palette is warm sand `#D9B990`, walnut `#8A6449`, soft ivory `#F3E9D9` and espresso `#30251E`.

## Procedural 3D furniture

The illustrative Scandinavian chair is authored in the project's source:

- `src/components/three/ChairGeometry.tsx`: actual chair geometry.
- `src/components/three/materials.ts`: generated wood grain, surface wear and interpolated restoration materials.
- `src/components/three/ChairScene.tsx`: lighting, camera and input interaction.
- `src/components/three/RestorationExperience.tsx`: scroll/manual restoration controls.

The hero does not depend on a downloaded third-party furniture model. Its textures are generated locally at runtime, so no external texture URLs or missing GLB files are required. The same geometry is used before and after restoration. It is an illustrative product-design exercise, not a scan of a RENOVA UF product or evidence of a completed customer project. Keep the visible illustration notice when reusing it.

`public/models/chair-fallback.svg` is a locally authored fallback illustration for unavailable WebGL/loading states. It is not a product photograph. `public/textures/README.txt` describes the procedural texture approach. `public/icons/favicon.svg` is an authored brand initial/favicon asset.

## Fonts

Cormorant Garamond and Manrope were obtained from Google Fonts. Their font files are bundled in `public/fonts/` and loaded from the same website origin, so visiting the website does not require Google Fonts requests.

| Typeface           | Included weights                            | Source                                                                                                                                                                     |
| ------------------ | ------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Cormorant Garamond | Variable 400–600 (Latin and Latin extended) | [Google Fonts family](https://fonts.google.com/specimen/Cormorant+Garamond) · [source repository/license](https://github.com/google/fonts/tree/main/ofl/cormorantgaramond) |
| Manrope            | Variable 400–700 (Latin and Latin extended) | [Google Fonts family](https://fonts.google.com/specimen/Manrope) · [source repository/license](https://github.com/google/fonts/tree/main/ofl/manrope)                      |

Both families are distributed under the SIL Open Font License 1.1. The original notices are bundled as `public/fonts/Cormorant-Garamond-OFL.txt` and `public/fonts/Manrope-OFL.txt`. Preserve those notices and license text when redistributing the files. `public/fonts/google-fonts-source.css` records the original downloaded font URLs; the site's actual style rules use the local copies. That source-reference CSS is not imported as a remote font dependency.

## Icons and software

Interface icons are provided by the `lucide-react` package under its ISC license. JavaScript dependencies retain their own licenses; exact resolved package versions are recorded in `package-lock.json`. The ZIP omits `node_modules`; installing dependencies restores the packages and their license files.

## Photographs and uploaded models

No owner product, restoration or team photographs were supplied, and none have been invented or substituted with stock photos. The catalog and relevant galleries use explicit empty states. The owner can upload authentic photographs and optional product GLB models through the protected Admin interface after configuring Supabase and Pages Functions.

Before uploading, confirm that RENOVA UF has permission to publish each asset and any identifiable people in it. Before/after images must show the same actual piece. Product GLBs must use embedded JPEG/PNG textures without Draco, Meshopt or KTX2 extensions. A product GLB should represent that product and include all resources within the file; external `uri` references are rejected. Keep asset licenses/permissions with the business records. Public Storage buckets must contain only non-sensitive marketing assets.

The Instagram section is a link to the supplied account, not an embedded live feed or a claim that any particular social image has been licensed or copied.
