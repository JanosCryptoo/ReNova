import {
  ApiError,
  assertOrigin,
  database,
  handler,
  json,
  readJson,
  record,
  stripeClient,
  uuid,
  verifyOrderToken,
} from '../../server/runtime';
export const onRequest = handler('POST', async ({ request, env }) => {
  assertOrigin(request, env);
  const body = record(await readJson(request));
  const orderId = uuid(body.orderId);
  await verifyOrderToken(orderId, body.statusToken, env);
  const db = database(env);
  const { data: order, error } = await db
    .from('orders')
    .select('stripe_session_id,status')
    .eq('id', orderId)
    .maybeSingle();
  if (error || !order) throw new ApiError(404, 'Beställningen kunde inte hittas.');
  if (['paid', 'payment_pending'].includes(order.status))
    throw new ApiError(409, 'Betalningen behandlas eller är redan klar. Kontakta RENOVA UF.');
  if (['expired', 'failed', 'cancelled'].includes(order.status))
    return json({ ok: true, status: order.status });
  if (!order.stripe_session_id)
    throw new ApiError(409, 'Reservationen behöver kontrolleras av RENOVA UF.');
  const stripe = stripeClient(env);
  let session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
  if (session.status === 'open') {
    try {
      session = await stripe.checkout.sessions.expire(session.id);
    } catch {
      session = await stripe.checkout.sessions.retrieve(session.id);
    }
  }
  // A concurrent successful payment wins. Never release from a browser's claim of cancellation.
  if (session.status !== 'expired' || session.payment_status === 'paid')
    throw new ApiError(409, 'Betalningen behandlas eller är redan klar.');
  const { error: releaseError } = await db.rpc('apply_checkout_event', {
    p_event_id: `cancel:${session.id}`,
    p_order_id: orderId,
    p_session_id: session.id,
    p_action: 'expired',
    p_total: session.amount_total,
    p_currency: session.currency,
    p_payment_reference: null,
  });
  if (releaseError) throw new ApiError(503, 'Reservationen kunde inte avslutas. Försök igen.');
  return json({ ok: true, status: 'expired' });
});
