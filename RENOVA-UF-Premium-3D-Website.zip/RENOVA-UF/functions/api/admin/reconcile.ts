import {
  ApiError,
  assertOrigin,
  database,
  handler,
  json,
  readJson,
  record,
  stripeClient,
  uuid,
} from '../../../server/runtime';
import type Stripe from 'stripe';

/** Recovery is explicit and admin-only. Time alone is never evidence that Stripe cannot collect money. */
export const onRequest = handler('POST', async ({ request, env }) => {
  assertOrigin(request, env);
  const bearer = request.headers.get('Authorization');
  if (!bearer?.startsWith('Bearer ')) throw new ApiError(401, 'Logga in först.');
  const db = database(env);
  const { data: identity, error: authError } = await db.auth.getUser(bearer.slice(7));
  if (authError || !identity.user) throw new ApiError(401, 'Logga in igen.');
  const { data: role, error: roleError } = await db
    .from('admin_roles')
    .select('role')
    .eq('user_id', identity.user.id)
    .maybeSingle();
  if (roleError || role?.role !== 'admin')
    throw new ApiError(403, 'Administratörsbehörighet krävs.');
  const body = record(await readJson(request));
  const orderId = uuid(body.orderId);
  const { data: order, error } = await db
    .from('orders')
    .select('id,total,status,stripe_session_id,created_at')
    .eq('id', orderId)
    .single();
  if (error) throw new ApiError(404, 'Beställningen kunde inte hittas.');
  if (['paid', 'expired', 'failed', 'cancelled'].includes(order.status))
    return json({ status: order.status, message: 'Beställningen är redan avslutad.' });
  const stripe = stripeClient(env);
  let session: Stripe.Checkout.Session | undefined;
  if (order.stripe_session_id)
    session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
  else {
    const created = Math.floor(new Date(order.created_at).getTime() / 1000);
    if (Date.now() / 1000 < created + 45 * 60)
      throw new ApiError(409, 'Vänta minst 45 minuter innan en ofullständig reservation frigörs.');
    let starting_after: string | undefined;
    let finished = false;
    for (let page = 0; page < 20; page++) {
      const list = await stripe.checkout.sessions.list({
        created: { gte: created - 60, lte: created + 45 * 60 },
        limit: 100,
        starting_after,
      });
      const matches = list.data.filter(
        (candidate) =>
          candidate.metadata?.order_id === orderId && candidate.client_reference_id === orderId,
      );
      if (matches.length > 1 || (session && matches.length))
        throw new ApiError(
          409,
          'Flera betalningar hittades. Kontrollera dem i Stripe innan lagret ändras.',
        );
      if (matches[0]) session = matches[0];
      if (!list.has_more) {
        finished = true;
        break;
      }
      starting_after = list.data.at(-1)?.id;
      if (!starting_after) break;
    }
    if (!finished)
      throw new ApiError(
        503,
        'Betalningshistoriken kunde inte kontrolleras helt. Lagret är fortsatt reserverat.',
      );
    if (!session) {
      const { error: releaseError } = await db.rpc('release_unattached_order', {
        p_order_id: orderId,
      });
      if (releaseError)
        throw new ApiError(409, 'Reservationen ändrades under kontrollen. Försök igen.');
      return json({
        status: 'cancelled',
        message: 'Ingen betalning hittades i Stripe. Reservationen har frigjorts.',
      });
    }
    const { error: attachError } = await db.rpc('attach_checkout_session', {
      p_order_id: orderId,
      p_session_id: session.id,
    });
    if (attachError) throw new ApiError(409, 'Betalningsreferensen kunde inte kopplas.');
  }
  if (session.status === 'open' && session.expires_at <= Date.now() / 1000) {
    try {
      session = await stripe.checkout.sessions.expire(session.id);
    } catch {
      session = await stripe.checkout.sessions.retrieve(session.id);
    }
  }
  let action: 'paid' | 'expired' | 'pending' | 'failed' | undefined;
  if (session.payment_status === 'paid') action = 'paid';
  else if (session.status === 'expired') action = 'expired';
  else if (session.status === 'complete') {
    action = 'pending';
    // Failed delayed payments are released only after retrieving their authoritative PaymentIntent.
    const intentId =
      typeof session.payment_intent === 'string'
        ? session.payment_intent
        : session.payment_intent?.id;
    if (intentId) {
      const intent = await stripe.paymentIntents.retrieve(intentId);
      if (intent.status === 'canceled') action = 'failed';
    }
  }
  if (action) {
    const paymentReference =
      typeof session.payment_intent === 'string'
        ? session.payment_intent
        : session.payment_intent?.id || null;
    const { error: applyError } = await db.rpc('apply_checkout_event', {
      p_event_id: `reconcile:${session.id}:${action}`,
      p_order_id: orderId,
      p_session_id: session.id,
      p_action: action,
      p_total: session.amount_total,
      p_currency: session.currency,
      p_payment_reference: paymentReference,
    });
    if (applyError)
      throw new ApiError(
        409,
        'Ordern kunde inte stämmas av. Kontrollera belopp och betalning i Stripe.',
      );
  }
  return json({
    status: action === 'pending' ? 'payment_pending' : action || 'reserved',
    message: 'Reservationen har kontrollerats mot Stripe.',
  });
});
