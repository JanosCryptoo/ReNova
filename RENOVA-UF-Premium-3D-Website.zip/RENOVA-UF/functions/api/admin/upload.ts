import { validateAsset } from '../../../server/assets';
import { ApiError, assertOrigin, database, handler, json } from '../../../server/runtime';
async function readUpload(request: Request): Promise<FormData> {
  const contentType = request.headers.get('Content-Type') || '';
  if (!contentType.startsWith('multipart/form-data;'))
    throw new ApiError(415, 'Filuppladdning krävs.');
  const max = 20 * 1024 * 1024 + 65536;
  if (Number(request.headers.get('Content-Length') || 0) > max || !request.body)
    throw new ApiError(413, 'Filen är för stor.');
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > max) {
      await reader.cancel();
      throw new ApiError(413, 'Filen är för stor.');
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  chunks.length = 0; // Drop chunk references before multipart decoding allocates its File.
  try {
    return await new Response(bytes, { headers: { 'Content-Type': contentType } }).formData();
  } catch {
    throw new ApiError(400, 'Filuppladdningen kunde inte läsas.');
  }
}
export const onRequest = handler('POST', async ({ request, env }) => {
  assertOrigin(request, env);
  const token = request.headers.get('Authorization');
  if (!token?.startsWith('Bearer ')) throw new ApiError(401, 'Logga in först.');
  const db = database(env);
  const { data: identity, error: authError } = await db.auth.getUser(token.slice(7));
  if (authError || !identity.user) throw new ApiError(401, 'Logga in igen.');
  const { data: role, error: roleError } = await db
    .from('admin_roles')
    .select('role')
    .eq('user_id', identity.user.id)
    .maybeSingle();
  if (roleError || role?.role !== 'admin')
    throw new ApiError(403, 'Administratörsbehörighet krävs.');
  // Parsing buffers are scoped separately and released before validating/uploading the file.
  const form = await readUpload(request);
  const file = form.get('file');
  if (!(file instanceof File) || Array.from(form.keys()).length !== 2)
    throw new ApiError(400, 'Välj en fil.');
  const asset = new Uint8Array(await file.arrayBuffer());
  const format = validateAsset(asset, form.get('kind'));
  const path = `${identity.user.id}/${crypto.randomUUID()}.${format.extension}`;
  const { error } = await db.storage
    .from(format.bucket)
    .upload(path, asset, { contentType: format.mime, cacheControl: '3600', upsert: false });
  if (error)
    throw new ApiError(503, 'Filen kunde inte sparas. Kontrollera att lagringen är konfigurerad.');
  return json({ url: db.storage.from(format.bucket).getPublicUrl(path).data.publicUrl }, 201);
});
