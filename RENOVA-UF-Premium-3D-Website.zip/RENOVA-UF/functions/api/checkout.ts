import {
  ApiError,
  assertOrigin,
  checkoutReady,
  database,
  handler,
  json,
  orderToken,
  readJson,
  sha256,
  siteOrigin,
  stripeClient,
  verifyHuman,
} from '../../server/runtime';
import { type ReservedOrder, validateCheckout } from '../../server/checkout';
export const onRequest = handler('POST', async ({ request, env }) => {
  if (!checkoutReady(env)) throw new ApiError(503, 'Betalningar är inte aktiverade ännu.');
  assertOrigin(request, env);
  const input = validateCheckout(await readJson(request));
  await verifyHuman(input.turnstileToken, request, env);
  const db = database(env);
  const fingerprint = await sha256(
    JSON.stringify({ items: input.items, customer: input.customer }),
  );
  const { data, error } = await db.rpc('reserve_order', {
    p_order_id: input.requestId,
    p_items: input.items,
    p_customer_name: input.customer.name,
    p_customer_email: input.customer.email,
    p_fingerprint: fingerprint,
  });
  if (error) {
    if (error.message.includes('OUT_OF_STOCK'))
      throw new ApiError(409, 'En möbel är redan såld eller reserverad. Uppdatera varukorgen.');
    if (error.message.includes('REQUEST_CONFLICT'))
      throw new ApiError(409, 'Varukorgen har ändrats. Börja om i kassan.');
    throw new ApiError(503, 'Beställningen kunde inte reserveras. Försök igen.');
  }
  const order = data as ReservedOrder;
  const stripe = stripeClient(env);
  const token = await orderToken(order.id, env);
  if (order.stripe_session_id) {
    const session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
    if (session.status === 'open' && session.url)
      return json({ url: session.url, orderId: order.id, statusToken: token });
    throw new ApiError(409, 'Den här betalningen har avslutats. Kontrollera din beställning.');
  }
  if (order.status !== 'creating')
    throw new ApiError(409, 'Den här beställningen har redan avslutats.');
  // Stable across retries. Never create a second Stripe Session for the same reservation.
  const expiresAt = Math.floor(new Date(order.created_at).getTime() / 1000) + 40 * 60;
  if (expiresAt < Math.floor(Date.now() / 1000) + 30 * 60 + 10) {
    throw new ApiError(
      409,
      'Reservationen behöver kontrolleras av RENOVA UF. Kontakta oss innan du försöker igen.',
    );
  }
  const resultUrl = `${siteOrigin(env)}/bestallning?orderId=${order.id}&token=${token}`;
  const session = await stripe.checkout.sessions.create(
    {
      mode: 'payment',
      locale: 'sv',
      client_reference_id: order.id,
      customer_email: order.customer_email,
      payment_method_types: env.STRIPE_ENABLE_SWISH === 'true' ? ['card', 'swish'] : ['card'],
      line_items: order.items.map((item) => ({
        quantity: item.quantity,
        price_data: { currency: 'sek', unit_amount: item.price, product_data: { name: item.name } },
      })),
      metadata: { order_id: order.id },
      payment_intent_data: { metadata: { order_id: order.id } },
      expires_at: expiresAt,
      success_url: `${resultUrl}&result=success`,
      cancel_url: `${resultUrl}&result=cancel`,
      custom_text: {
        submit: { message: 'Upphämtning i Eskilstuna efter överenskommelse med RENOVA UF.' },
      },
    },
    { idempotencyKey: `renova-checkout-${order.id}` },
  );
  if (!session.url) throw new ApiError(503, 'Betalningssidan kunde inte öppnas.');
  const { error: attachError } = await db.rpc('attach_checkout_session', {
    p_order_id: order.id,
    p_session_id: session.id,
  });
  if (attachError) {
    // Do not release inventory on an ambiguous external outcome. A retry / webhook recovers it.
    throw new ApiError(
      503,
      'Betalningen förbereddes men kunde inte bekräftas. Försök igen med samma varukorg.',
    );
  }
  return json({ url: session.url, orderId: order.id, statusToken: token });
});
