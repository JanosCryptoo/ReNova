import { ApiError, database, handler, json, uuid, verifyOrderToken } from '../../server/runtime';
export const onRequest = handler('GET', async ({ request, env }) => {
  const params = new URL(request.url).searchParams;
  const orderId = uuid(params.get('orderId'));
  await verifyOrderToken(orderId, params.get('token'), env);
  const { data, error } = await database(env)
    .from('orders')
    .select('status,total')
    .eq('id', orderId)
    .maybeSingle();
  if (error) throw new ApiError(503, 'Beställningen kunde inte kontrolleras.');
  if (!data) throw new ApiError(404, 'Beställningen kunde inte hittas.');
  return json({ status: data.status, total: data.total, currency: 'sek' });
});
