import { checkoutReady, contactReady, handler, json } from '../../server/runtime';
export const onRequest = handler('GET', async ({ env }) =>
  json({
    checkoutEnabled: checkoutReady(env),
    contactEnabled: contactReady(env),
    turnstileSiteKey: contactReady(env) ? env.TURNSTILE_SITE_KEY : null,
  }),
);
