import { json } from '../../server/runtime';
/** Keep unknown API paths out of the frontend SPA fallback. */
export const onRequest = async () => json({ error: 'API-adressen finns inte.' }, 404);
