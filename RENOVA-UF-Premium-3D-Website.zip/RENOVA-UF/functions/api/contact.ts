import {
  ApiError,
  assertOrigin,
  contactReady,
  database,
  emailField,
  handler,
  json,
  readJson,
  record,
  textField,
  uuid,
  verifyHuman,
} from '../../server/runtime';
export const onRequest = handler('POST', async ({ request, env }) => {
  if (!contactReady(env))
    throw new ApiError(
      503,
      'Kontaktformuläret är inte aktiverat ännu. Kontakta oss via Instagram.',
    );
  assertOrigin(request, env);
  const body = record(await readJson(request));
  const name = textField(body.name, 2, 120);
  const email = emailField(body.email);
  const message = textField(body.message, 10, 4000);
  if (body.website) throw new ApiError(400, 'Meddelandet kunde inte skickas.');
  const product_id = body.product_id ? uuid(body.product_id) : null;
  await verifyHuman(body.turnstileToken, request, env);
  const { error } = await database(env)
    .from('contact_messages')
    .insert({ name, email, message, product_id });
  if (error) throw new ApiError(503, 'Meddelandet kunde inte sparas. Försök igen senare.');
  return json({ ok: true, message: 'Tack! Ditt meddelande har sparats till RENOVA UF.' }, 201);
});
