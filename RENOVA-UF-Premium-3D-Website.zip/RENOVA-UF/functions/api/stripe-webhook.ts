import Stripe from 'stripe';
import {
  ApiError,
  database,
  handler,
  json,
  limitedText,
  stripeClient,
  uuidPattern,
} from '../../server/runtime';
export const onRequest = handler('POST', async ({ request, env }) => {
  if (!env.STRIPE_WEBHOOK_SECRET) throw new ApiError(503, 'Webhook är inte konfigurerad.');
  const signature = request.headers.get('Stripe-Signature');
  if (!signature) throw new ApiError(400, 'Ogiltig signatur.');
  const raw = await limitedText(request, 262_144);
  const stripe = stripeClient(env);
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      raw,
      signature,
      env.STRIPE_WEBHOOK_SECRET,
      undefined,
      Stripe.createSubtleCryptoProvider(),
    );
  } catch {
    throw new ApiError(400, 'Ogiltig signatur.');
  }
  if (event.livemode !== env.STRIPE_SECRET_KEY?.startsWith('sk_live_'))
    throw new ApiError(400, 'Fel betalningsmiljö.');
  const relevant = [
    'checkout.session.completed',
    'checkout.session.async_payment_succeeded',
    'checkout.session.async_payment_failed',
    'checkout.session.expired',
  ];
  if (!relevant.includes(event.type)) return json({ received: true });
  const session = event.data.object as Stripe.Checkout.Session;
  const orderId = session.metadata?.order_id;
  if (
    !orderId ||
    !uuidPattern.test(orderId) ||
    session.client_reference_id !== orderId ||
    session.mode !== 'payment'
  ) {
    throw new ApiError(400, 'Orderreferens saknas.');
  }
  let action = 'pending';
  if (event.type === 'checkout.session.expired') action = 'expired';
  else if (event.type === 'checkout.session.async_payment_failed') action = 'failed';
  else if (session.payment_status === 'paid') action = 'paid';
  else if (event.type === 'checkout.session.async_payment_succeeded')
    throw new ApiError(400, 'Betalningen är inte bekräftad.');
  const paymentReference =
    typeof session.payment_intent === 'string'
      ? session.payment_intent
      : session.payment_intent?.id || null;
  const { error } = await database(env).rpc('apply_checkout_event', {
    p_event_id: event.id,
    p_order_id: orderId,
    p_session_id: session.id,
    p_action: action,
    p_total: session.amount_total,
    p_currency: session.currency,
    p_payment_reference: paymentReference,
  });
  if (error) {
    // A non-2xx response asks Stripe to retry; no event is marked applied unless the transaction commits.
    throw new ApiError(503, 'Ordern kunde inte uppdateras.');
  }
  return json({ received: true });
});
