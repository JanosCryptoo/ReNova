// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, useLocation } from 'react-router-dom';
import type { Product } from '../src/types';
import BeforeAfter from '../src/components/before-after/BeforeAfter';
import { CartProvider, useCart } from '../src/components/CartProvider';
import ProductCard from '../src/components/products/ProductCard';
import Cart from '../src/pages/Cart';
import Admin from '../src/pages/Admin';
import { CHECKOUT_ATTEMPT_KEY, readAttempt } from '../src/lib/checkoutAttempt';
import ChairScene from '../src/components/three/ChairScene';

const mocks = vi.hoisted(() => ({
  products: [] as Product[],
  checkoutEnabled: true,
  createCheckout: vi.fn(),
}));
vi.mock('../src/hooks/useCatalog', () => ({
  useCatalog: () => ({ products: mocks.products, loading: false, error: '', reload: vi.fn() }),
}));
vi.mock('../src/hooks/useCapabilities', () => ({
  useCapabilities: () => ({
    checkoutEnabled: mocks.checkoutEnabled,
    contactEnabled: false,
    loading: false,
  }),
}));
vi.mock('../src/services/api', () => ({ createCheckout: mocks.createCheckout }));
vi.mock('../src/services/supabase', () => ({
  isSupabaseConfigured: false,
  supabase: null,
  requireSupabase: () => {
    throw new Error('No database is configured for this test.');
  },
}));

// Fictional records exist in tests only. They never seed the public catalog.
const fixture: Product = {
  id: '15946f46-4180-4374-8e20-4fc153f84e30',
  name: 'TEST',
  description: 'TEST fixture',
  price: 125050,
  category: 'Stolar',
  condition: 'TEST',
  dimensions: 'TEST',
  stock: 1,
  availability: 'available',
  published: true,
  featured: true,
  model_url: null,
  created_at: '2026-11-20T00:00:00Z',
  product_images: [
    {
      image_url: 'https://test.supabase.co/storage/v1/object/public/furniture-images/test.webp',
      sort_order: 0,
    },
  ],
};

function CartProbe() {
  const { items, add, clear, remove, notice } = useCart();
  return (
    <>
      <output aria-label="TEST cart state">{JSON.stringify(items)}</output>
      <p role="status" aria-label="TEST cart notice">
        {notice}
      </p>
      <button onClick={() => add(fixture)}>Add TEST</button>
      <button
        onClick={() =>
          add({
            ...fixture,
            id: 'ed6a234a-8cc0-426c-adb7-6d48d0460273',
            stock: 0,
            availability: 'sold',
          })
        }
      >
        Add unavailable TEST
      </button>
      <button onClick={() => remove(fixture.id)}>Remove TEST</button>
      <button onClick={clear}>Clear TEST cart</button>
    </>
  );
}

function LocationProbe() {
  return <output aria-label="TEST route">{useLocation().pathname}</output>;
}

function mountCartPage() {
  return render(
    <MemoryRouter initialEntries={['/varukorg']}>
      <CartProvider>
        <Cart />
      </CartProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => {
  localStorage.clear();
  sessionStorage.clear();
  mocks.products = [fixture];
  mocks.checkoutEnabled = true;
  mocks.createCheckout.mockReset();
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('photographic before-and-after interaction', () => {
  it('labels both images and updates divider, clipping and accessible value in both directions', () => {
    const { container } = render(
      <BeforeAfter before="/test-before.webp" after="/test-after.webp" title="TEST" />,
    );
    const slider = screen.getByRole('slider', {
      name: 'Dra för att jämföra TEST före och efter restaurering',
    });
    expect(screen.getByAltText('TEST före restaurering').getAttribute('src')).toBe(
      '/test-before.webp',
    );
    expect(screen.getByAltText('TEST efter restaurering').getAttribute('src')).toBe(
      '/test-after.webp',
    );
    expect((slider as HTMLInputElement).value).toBe('50');
    expect(slider.getAttribute('min')).toBe('0');
    expect(slider.getAttribute('max')).toBe('100');
    for (const position of [80, 100, 0, 35]) {
      // jsdom does not implement native range keyboard stepping. This dispatches
      // the same change event produced by pointer/touch/keyboard range input.
      fireEvent.change(slider, { target: { value: String(position) } });
      expect(
        (container.querySelector('.comparison-before') as HTMLElement).style.clipPath.replace(
          /0px/g,
          '0',
        ),
      ).toBe(`inset(0 ${100 - position}% 0 0)`);
      expect((container.querySelector('.comparison-line') as HTMLElement).style.left).toBe(
        `${position}%`,
      );
      expect(slider.getAttribute('aria-valuetext')).toBe(`${position} procent före restaurering`);
    }
  });
});

describe('shopping cart interactions and persistence', () => {
  it('adds a unique piece once, rejects unavailable stock, and removes persisted lines', async () => {
    const user = userEvent.setup();
    render(
      <CartProvider>
        <CartProbe />
      </CartProvider>,
    );
    await user.click(screen.getByRole('button', { name: 'Add TEST' }));
    expect(JSON.parse(localStorage.getItem('renova-cart-v1')!)).toEqual([
      { productId: fixture.id, quantity: 1 },
    ]);
    await user.click(screen.getByRole('button', { name: 'Add TEST' }));
    expect(screen.getByRole('status', { name: 'TEST cart notice' }).textContent).toBe(
      'Möbeln finns redan i din varukorg.',
    );
    await user.click(screen.getByRole('button', { name: 'Add unavailable TEST' }));
    expect(screen.getByRole('status', { name: 'TEST cart notice' }).textContent).toBe(
      'Möbeln är inte tillgänglig just nu.',
    );
    expect(JSON.parse(screen.getByLabelText('TEST cart state').textContent!)).toHaveLength(1);
    await user.click(screen.getByRole('button', { name: 'Remove TEST' }));
    expect(JSON.parse(localStorage.getItem('renova-cart-v1')!)).toEqual([]);
  });

  it('restores saved contents and clears them when requested', async () => {
    localStorage.setItem(
      'renova-cart-v1',
      JSON.stringify([{ productId: fixture.id, quantity: 1 }]),
    );
    const user = userEvent.setup();
    render(
      <CartProvider>
        <CartProbe />
      </CartProvider>,
    );
    expect(JSON.parse(screen.getByLabelText('TEST cart state').textContent!)).toEqual([
      { productId: fixture.id, quantity: 1 },
    ]);
    await user.click(screen.getByRole('button', { name: 'Clear TEST cart' }));
    expect(screen.getByLabelText('TEST cart state').textContent).toBe('[]');
    expect(localStorage.getItem('renova-cart-v1')).toBe('[]');
  });

  it('continues shopping when browser storage cannot be written', async () => {
    const user = userEvent.setup();
    render(
      <CartProvider>
        <CartProbe />
      </CartProvider>,
    );
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new DOMException('TEST storage denied', 'SecurityError');
    });
    await user.click(screen.getByRole('button', { name: 'Add TEST' }));
    expect(JSON.parse(screen.getByLabelText('TEST cart state').textContent!)).toEqual([
      { productId: fixture.id, quantity: 1 },
    ]);
  });
});

describe('product catalog cards', () => {
  it('shows the SEK price, opens the product route and adds the real record to the cart', async () => {
    const user = userEvent.setup();
    render(
      <MemoryRouter>
        <CartProvider>
          <ProductCard product={fixture} />
          <LocationProbe />
          <CartProbe />
        </CartProvider>
      </MemoryRouter>,
    );
    const price = new Intl.NumberFormat('sv-SE', {
      style: 'currency',
      currency: 'SEK',
      maximumFractionDigits: 2,
    }).format(fixture.price / 100);
    expect(screen.getByText(price, { normalizer: (value) => value }).textContent).toBe(price);
    expect(screen.getByAltText('TEST').getAttribute('src')).toContain('/test.webp');
    await user.click(screen.getByRole('link', { name: 'TEST' }));
    expect(screen.getByLabelText('TEST route').textContent).toBe(`/mobler/${fixture.id}`);
    await user.click(screen.getByRole('button', { name: 'Lägg TEST i varukorgen' }));
    expect(JSON.parse(screen.getByLabelText('TEST cart state').textContent!)).toEqual([
      { productId: fixture.id, quantity: 1 },
    ]);
  });

  it('disables purchase of a reserved piece', () => {
    render(
      <MemoryRouter>
        <CartProvider>
          <ProductCard product={{ ...fixture, stock: 0, availability: 'reserved' }} />
        </CartProvider>
      </MemoryRouter>,
    );
    expect(screen.getByText('Reserverad')).toBeTruthy();
    expect(
      (screen.getByRole('button', { name: 'Lägg TEST i varukorgen' }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
  });
});

describe('checkout recovery after an ambiguous network failure', () => {
  it('retains the same request ID after remount and permits resuming its own now-reserved piece', async () => {
    const user = userEvent.setup();
    localStorage.setItem(
      'renova-cart-v1',
      JSON.stringify([{ productId: fixture.id, quantity: 1 }]),
    );
    mocks.createCheckout.mockRejectedValue(new Error('TEST network response lost'));
    const first = mountCartPage();
    await user.type(screen.getByRole('textbox', { name: 'Namn' }), 'TEST Customer');
    await user.type(screen.getByRole('textbox', { name: 'E-post' }), 'test@example.com');
    await user.click(screen.getByRole('checkbox'));
    await user.click(screen.getByRole('button', { name: 'Till säker betalning' }));
    await screen.findByRole('alert');
    expect(mocks.createCheckout).toHaveBeenCalledTimes(1);
    const requestId = mocks.createCheckout.mock.calls[0][2];
    expect(readAttempt()?.id).toBe(requestId);
    expect(sessionStorage.getItem(CHECKOUT_ATTEMPT_KEY)).toContain(requestId);
    first.unmount();

    // A fresh catalog fetch now sees the reservation made before the lost response.
    mocks.products = [{ ...fixture, stock: 0, availability: 'reserved' }];
    mountCartPage();
    expect((screen.getByRole('textbox', { name: 'Namn' }) as HTMLInputElement).value).toBe(
      'TEST Customer',
    );
    expect((screen.getByRole('textbox', { name: 'E-post' }) as HTMLInputElement).value).toBe(
      'test@example.com',
    );
    const resume = screen.getByRole('button', {
      name: 'Återuppta säker betalning',
    }) as HTMLButtonElement;
    expect(resume.disabled).toBe(false);
    await user.click(screen.getByRole('checkbox'));
    await user.click(resume);
    await waitFor(() => expect(mocks.createCheckout).toHaveBeenCalledTimes(2));
    expect(mocks.createCheckout.mock.calls[1]).toEqual(mocks.createCheckout.mock.calls[0]);
    await screen.findByRole('alert');

    // Changing the customer cannot reuse the old reservation fingerprint.
    await user.type(screen.getByRole('textbox', { name: 'Namn' }), ' changed');
    expect(
      (screen.getByRole('button', { name: 'Till säker betalning' }) as HTMLButtonElement).disabled,
    ).toBe(true);
  });

  it('keeps checkout disabled when payments are unconfigured', () => {
    mocks.checkoutEnabled = false;
    localStorage.setItem(
      'renova-cart-v1',
      JSON.stringify([{ productId: fixture.id, quantity: 1 }]),
    );
    mountCartPage();
    expect(
      (screen.getByRole('button', { name: 'Till säker betalning' }) as HTMLButtonElement).disabled,
    ).toBe(true);
    expect(screen.getByText(/Onlinebetalning är inte tillgänglig ännu/)).toBeTruthy();
    expect(mocks.createCheckout).not.toHaveBeenCalled();
  });
});

describe('unconfigured administrator area', () => {
  it('offers setup instructions without a fake login or customer records', () => {
    render(
      <MemoryRouter>
        <Admin />
      </MemoryRouter>,
    );
    expect(screen.getByText(/Anslut er databas/)).toBeTruthy();
    expect(screen.queryByRole('textbox')).toBeNull();
    expect(screen.queryByLabelText('Lösenord')).toBeNull();
    expect(screen.queryByRole('button', { name: 'Logga in' })).toBeNull();
    expect(screen.getByRole('link', { name: 'Till startsidan' }).getAttribute('href')).toBe('/');
  });
});

describe('unavailable WebGL', () => {
  beforeEach(() => {
    vi.stubGlobal('matchMedia', (query: string) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: vi.fn(),
      removeListener: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    }));
    vi.stubGlobal(
      'IntersectionObserver',
      class {
        observe() {}
        unobserve() {}
        disconnect() {}
        takeRecords() {
          return [];
        }
      },
    );
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(null);
  });

  it('falls back to the bundled illustration with an explicit browser-support message', async () => {
    const { container } = render(<ChairScene />);
    await screen.findByText('En stillbild visas eftersom 3D inte stöds i din webbläsare.');
    expect(screen.getByAltText('Illustration av en skandinavisk trästol').getAttribute('src')).toBe(
      '/models/chair-fallback.svg',
    );
    expect(container.querySelector('.chair-scene')?.getAttribute('data-three-fallback')).toBe(
      'true',
    );
    expect(container.querySelector('canvas')).toBeNull();
    expect(screen.queryByRole('button', { name: 'Vrid möbeln åt vänster' })).toBeNull();
  });

  it('never substitutes the illustrative chair for a genuine product model', async () => {
    const { container } = render(
      <ChairScene modelUrl="https://test.supabase.co/storage/v1/object/public/furniture-models/test.glb" />,
    );
    await screen.findByText('Du kan fortfarande se produktens fotografier.');
    expect(screen.getByText('3D-visningen är inte tillgänglig.')).toBeTruthy();
    expect(container.querySelector('img')).toBeNull();
    expect(container.querySelector('canvas')).toBeNull();
  });
});
