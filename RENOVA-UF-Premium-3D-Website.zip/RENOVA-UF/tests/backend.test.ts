import { describe, expect, it } from 'vitest';
import { validateCheckout } from '../server/checkout';
import {
  checkoutReady,
  contactReady,
  limitedText,
  orderToken,
  verifyOrderToken,
  type Env,
} from '../server/runtime';
import { onRequest as config } from '../functions/api/config';
import { onRequest as checkout } from '../functions/api/checkout';
import { onRequest as contact } from '../functions/api/contact';
import { onRequest as webhook } from '../functions/api/stripe-webhook';
import { onRequest as unknownApi } from '../functions/api/[[path]]';
import { validateAsset } from '../server/assets';
import Stripe from 'stripe';

const id = '8f135b9a-454d-410b-b9db-45b031ead987';
const product = '67887b3a-9369-478b-b586-581d90a2b6b4';
const input = {
  requestId: id,
  items: [{ productId: product, quantity: 1 }],
  customer: { name: 'Test Kund', email: 'kund@example.com' },
};
describe('checkout boundaries', () => {
  it('uses IDs and quantities, discarding client prices', () => {
    expect(
      validateCheckout({ ...input, total: 1, items: [{ ...input.items[0], price: 1 }] }).items,
    ).toEqual([{ productId: product, quantity: 1 }]);
  });
  it.each([0, -1, 1.5, 11, '1', null])('rejects invalid quantity %s', (quantity) => {
    expect(() =>
      validateCheckout({ ...input, items: [{ productId: product, quantity }] }),
    ).toThrow();
  });
  it('rejects duplicate and malformed product IDs', () => {
    expect(() => validateCheckout({ ...input, items: [...input.items, ...input.items] })).toThrow();
    expect(() =>
      validateCheckout({ ...input, items: [{ productId: 'sql-injection', quantity: 1 }] }),
    ).toThrow();
  });
  it('validates customer email and bounded cart', () => {
    expect(() => validateCheckout({ ...input, customer: { name: 'T', email: 'x' } })).toThrow();
    expect(() => validateCheckout({ ...input, items: [] })).toThrow();
  });
});
describe('fail-closed service configuration', () => {
  it('does not enable services without configuration', async () => {
    expect(checkoutReady({})).toBe(false);
    expect(contactReady({})).toBe(false);
    const response = await config({
      request: new Request('https://example.com/api/config'),
      env: {},
    });
    expect(await response.json()).toEqual({
      checkoutEnabled: false,
      contactEnabled: false,
      turnstileSiteKey: null,
    });
  });
  it('requires an explicit live payment gate', () => {
    const env: Env = {
      SUPABASE_URL: 'https://example.supabase.co',
      SUPABASE_SECRET_KEY: 'test-only',
      SITE_URL: 'https://example.com',
      CHECKOUT_ENABLED: 'true',
      STRIPE_SECRET_KEY: 'sk_live_test_only',
      STRIPE_WEBHOOK_SECRET: 'test-only',
      ORDER_TOKEN_SECRET: 'x'.repeat(32),
      TURNSTILE_SECRET_KEY: 'test-only',
      TURNSTILE_SITE_KEY: 'test-only',
    };
    expect(checkoutReady(env)).toBe(false);
    expect(checkoutReady({ ...env, ALLOW_LIVE_PAYMENTS: 'true' })).toBe(true);
  });
  it('unconfigured checkout and contact return 503 instead of fake success', async () => {
    for (const fn of [checkout, contact]) {
      const response = await fn({
        request: new Request('https://example.com/api/action', { method: 'POST' }),
        env: {},
      });
      expect(response.status).toBe(503);
      expect(response.headers.get('Cache-Control')).toBe('no-store');
    }
  });
  it('rejects wrong methods and unknown API routes', async () => {
    expect(
      (await checkout({ request: new Request('https://example.com/api/checkout'), env: {} }))
        .status,
    ).toBe(405);
    expect((await unknownApi()).status).toBe(404);
  });
  it('rejects unsigned webhook before touching database', async () => {
    const response = await webhook({
      request: new Request('https://example.com/api/stripe-webhook', { method: 'POST' }),
      env: { STRIPE_WEBHOOK_SECRET: 'test-only' },
    });
    expect(response.status).toBe(400);
  });
  it('verifies signed raw webhook bodies with Web Crypto and rejects tampering', async () => {
    const stripe = new Stripe('sk_test_example', { httpClient: Stripe.createFetchHttpClient() });
    const payload = JSON.stringify({
      id: 'evt_test_only',
      type: 'customer.updated',
      livemode: false,
      data: { object: {} },
    });
    const signature = await stripe.webhooks.generateTestHeaderStringAsync({
      payload,
      secret: 'whsec_test_only',
      cryptoProvider: Stripe.createSubtleCryptoProvider(),
    });
    const env = { STRIPE_SECRET_KEY: 'sk_test_example', STRIPE_WEBHOOK_SECRET: 'whsec_test_only' };
    const request = (body: string) =>
      new Request('https://example.com/api/stripe-webhook', {
        method: 'POST',
        body,
        headers: { 'Stripe-Signature': signature },
      });
    expect((await webhook({ request: request(payload), env })).status).toBe(200);
    expect((await webhook({ request: request(payload + ' '), env })).status).toBe(400);
  });
});
describe('server upload validation', () => {
  function glb(metadata: object) {
    const text = JSON.stringify(metadata);
    const padded = text.padEnd(Math.ceil(text.length / 4) * 4, ' ');
    const json = new TextEncoder().encode(padded);
    const bytes = new Uint8Array(json.length + 20);
    const view = new DataView(bytes.buffer);
    view.setUint32(0, 0x46546c67, true);
    view.setUint32(4, 2, true);
    view.setUint32(8, bytes.length, true);
    view.setUint32(12, json.length, true);
    view.setUint32(16, 0x4e4f534a, true);
    bytes.set(json, 20);
    return bytes;
  }
  it('rejects SVG disguised as an image and oversized files', () => {
    expect(() =>
      validateAsset(new TextEncoder().encode('<svg onload="alert(1)"></svg>'), 'image'),
    ).toThrow();
    expect(() => validateAsset(new Uint8Array(8 * 1024 * 1024 + 1), 'image')).toThrow();
  });
  it('accepts self-contained GLB structure and rejects external textures', () => {
    expect(validateAsset(glb({ asset: { version: '2.0' } }), 'model').mime).toBe(
      'model/gltf-binary',
    );
    expect(() =>
      validateAsset(
        glb({
          asset: { version: '2.0' },
          images: [{ uri: 'https://attacker.example/tracker.png' }],
        }),
        'model',
      ),
    ).toThrow();
    expect(() => validateAsset(glb({ asset: { version: '1.0' } }), 'model')).toThrow();
  });
  it('rejects models whose decoder dependencies are not bundled', () => {
    expect(() =>
      validateAsset(
        glb({ asset: { version: '2.0' }, extensionsRequired: ['KHR_texture_basisu'] }),
        'model',
      ),
    ).toThrow('utan Draco');
  });
});
describe('guest order access and request size', () => {
  it('signs order-specific opaque tokens and rejects forgery', async () => {
    const env = { ORDER_TOKEN_SECRET: 'test-only-'.repeat(6) };
    const token = await orderToken(id, env);
    await expect(verifyOrderToken(id, token, env)).resolves.toBeUndefined();
    await expect(verifyOrderToken(product, token, env)).rejects.toThrow();
    await expect(verifyOrderToken(id, '0'.repeat(64), env)).rejects.toThrow();
    expect(await orderToken(id, env)).toBe(token);
  });
  it('caps streamed bodies even without Content-Length', async () => {
    const request = new Request('https://example.com', { method: 'POST', body: 'x'.repeat(40) });
    await expect(limitedText(request, 20)).rejects.toThrow();
  });
});
