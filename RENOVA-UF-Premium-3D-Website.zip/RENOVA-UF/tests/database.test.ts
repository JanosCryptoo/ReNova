import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

// Runs actual PostgreSQL migrations. Only Supabase-owned auth/storage prerequisites are stubbed.
// PGlite is single-connection; a real hosted two-client concurrency test remains required.
let db: PGlite;
const adminId = 'bb592e07-7988-466a-8bf4-10240e4b6a3d';
const userId = '25c1d016-c606-4c40-8c53-5683af679742';
const fingerprint = 'a'.repeat(64);
async function role<T>(
  name: 'anon' | 'authenticated' | 'service_role',
  fn: () => Promise<T>,
  uid = '',
) {
  await db.exec(`set role ${name}`);
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [uid]);
  try {
    return await fn();
  } finally {
    await db.exec('reset role');
  }
}
async function product(stock = 1, published = true) {
  const id = crypto.randomUUID();
  await db.query(
    "insert into products(id,name,price,category,stock,published) values($1,'Testmöbel',125000,'Stolar',$2,$3)",
    [id, stock, published],
  );
  return id;
}
async function reserve(
  productId: string,
  orderId: string = crypto.randomUUID(),
  hash = fingerprint,
  quantity = 1,
) {
  const result = await role('service_role', () =>
    db.query<{ order: { id: string; total: number; status: string } }>(
      'select reserve_order($1,$2::jsonb,$3,$4,$5) as "order"',
      [orderId, JSON.stringify([{ productId, quantity }]), 'Test Kund', 'test@example.com', hash],
    ),
  );
  return result.rows[0].order;
}
async function event(
  orderId: string,
  action: string,
  eventId: string = crypto.randomUUID(),
  total = 125000,
) {
  return role('service_role', () =>
    db.query('select apply_checkout_event($1,$2,$3,$4,$5,$6,$7)', [
      eventId,
      orderId,
      `cs_test_${orderId}`,
      action,
      total,
      'sek',
      action === 'paid' ? `pi_${orderId}` : null,
    ]),
  );
}
async function state(productId: string) {
  return (
    await db.query<{ stock: number; availability: string }>(
      'select stock,availability from products where id=$1',
      [productId],
    )
  ).rows[0];
}

beforeAll(async () => {
  db = new PGlite();
  await db.exec(`
    create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create schema storage;
    grant usage on schema auth,storage,public to anon,authenticated,service_role;
    create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid; $$;
    create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
    alter table storage.objects enable row level security;
    grant select,insert,update,delete on storage.objects to authenticated;
  `);
  for (const name of [
    '20261120000000_renova_initial.sql',
    '20261120000001_reservation_recovery.sql',
  ]) {
    await db.exec(
      await readFile(
        fileURLToPath(new URL(`../supabase/migrations/${name}`, import.meta.url)),
        'utf8',
      ),
    );
  }
  await db.query('insert into auth.users(id) values ($1),($2)', [adminId, userId]);
  await db.query("insert into admin_roles(user_id,role) values($1,'admin')", [adminId]);
}, 30000);
afterAll(async () => {
  await db?.close();
});

describe('actual reservation SQL', () => {
  it('reserves a stock-one product at the database price and rejects another buyer atomically', async () => {
    const id = await product();
    const order = await reserve(id);
    expect(order.total).toBe(125000);
    expect(await state(id)).toEqual({ stock: 0, availability: 'reserved' });
    const rejectedOrder = crypto.randomUUID();
    await expect(reserve(id, rejectedOrder)).rejects.toThrow('OUT_OF_STOCK');
    expect(
      (await db.query('select id from orders where id=$1', [rejectedOrder])).rows,
    ).toHaveLength(0);
  });
  it('makes request retries idempotent and rejects changed payload fingerprints', async () => {
    const id = await product();
    const order = await reserve(id);
    expect((await reserve(id, order.id)).id).toBe(order.id);
    expect(
      (await db.query('select id from order_items where order_id=$1', [order.id])).rows,
    ).toHaveLength(1);
    await expect(reserve(id, order.id, 'b'.repeat(64))).rejects.toThrow('REQUEST_CONFLICT');
  });
  it('marks paid once and never restocks from later expiration', async () => {
    const id = await product();
    const order = await reserve(id);
    const eventId = crypto.randomUUID();
    await event(order.id, 'paid', eventId);
    await event(order.id, 'paid', eventId);
    await event(order.id, 'expired');
    expect(await state(id)).toEqual({ stock: 0, availability: 'sold' });
    expect(
      (await db.query<{ status: string }>('select status from orders where id=$1', [order.id]))
        .rows[0].status,
    ).toBe('paid');
  });
  it('returns expired stock exactly once across duplicate and distinct events', async () => {
    const id = await product();
    const order = await reserve(id);
    const eventId = crypto.randomUUID();
    await event(order.id, 'expired', eventId);
    await event(order.id, 'expired', eventId);
    await event(order.id, 'expired');
    expect(await state(id)).toEqual({ stock: 1, availability: 'available' });
    await expect(event(order.id, 'paid')).rejects.toThrow('LATE_PAYMENT_REQUIRES_REVIEW');
    expect(await state(id)).toEqual({ stock: 1, availability: 'available' });
  });
  it('holds stock during delayed payment and ignores obsolete expiration', async () => {
    const id = await product();
    const order = await reserve(id);
    await event(order.id, 'pending');
    await event(order.id, 'expired');
    expect(await state(id)).toEqual({ stock: 0, availability: 'reserved' });
    await event(order.id, 'paid');
    expect(await state(id)).toEqual({ stock: 0, availability: 'sold' });
  });
  it('rolls back invalid amounts without recording an applied event', async () => {
    const id = await product();
    const order = await reserve(id);
    const eventId = crypto.randomUUID();
    await expect(event(order.id, 'paid', eventId, 1)).rejects.toThrow('AMOUNT_MISMATCH');
    expect(
      (await db.query('select event_id from payment_events where event_id=$1', [eventId])).rows,
    ).toHaveLength(0);
    expect(await state(id)).toEqual({ stock: 0, availability: 'reserved' });
  });
  it('does not allow early recovery or recovery after session attachment', async () => {
    const id = await product();
    const order = await reserve(id);
    await expect(
      role('service_role', () => db.query('select release_unattached_order($1)', [order.id])),
    ).rejects.toThrow('UNSAFE_RELEASE');
    await db.query("update orders set created_at=now()-interval '46 minutes' where id=$1", [
      order.id,
    ]);
    await role('service_role', () => db.query('select release_unattached_order($1)', [order.id]));
    await role('service_role', () => db.query('select release_unattached_order($1)', [order.id]));
    expect(await state(id)).toEqual({ stock: 1, availability: 'available' });
    const another = await reserve(id);
    await role('service_role', () =>
      db.query('select attach_checkout_session($1,$2)', [another.id, `cs_test_${another.id}`]),
    );
    await db.query("update orders set created_at=now()-interval '46 minutes' where id=$1", [
      another.id,
    ]);
    await expect(
      role('service_role', () => db.query('select release_unattached_order($1)', [another.id])),
    ).rejects.toThrow('UNSAFE_RELEASE');
  });
});

describe('real PostgreSQL grants and RLS', () => {
  it('visitors see published products but no drafts or orders', async () => {
    const draft = await product(1, false);
    expect(
      await role(
        'anon',
        async () => (await db.query('select id from products where id=$1', [draft])).rows,
      ),
    ).toHaveLength(0);
    await expect(role('anon', () => db.query('select * from orders'))).rejects.toThrow(
      'permission denied',
    );
  });
  it('ordinary Auth users cannot mutate products, read contacts, or grant themselves admin', async () => {
    await expect(
      role(
        'authenticated',
        () => db.query("insert into products(name,price,category) values('Illicit',100,'Stolar')"),
        userId,
      ),
    ).rejects.toThrow('row-level security');
    expect(
      await role(
        'authenticated',
        async () => (await db.query('select * from contact_messages')).rows,
        userId,
      ),
    ).toHaveLength(0);
    expect(
      await role(
        'authenticated',
        async () => (await db.query('select * from orders')).rows,
        userId,
      ),
    ).toHaveLength(0);
    await expect(
      role(
        'authenticated',
        () => db.query("insert into admin_roles(user_id,role) values($1,'admin')", [userId]),
        userId,
      ),
    ).rejects.toThrow('permission denied');
  });
  it('neither visitors nor browser admins can call privileged payment RPCs', async () => {
    for (const caller of ['anon', 'authenticated'] as const) {
      await expect(
        role(
          caller,
          () => db.query('select release_unattached_order($1)', [crypto.randomUUID()]),
          adminId,
        ),
      ).rejects.toThrow('permission denied');
    }
  });
  it('admins can manage products but cannot override a reserved stock count', async () => {
    const id = crypto.randomUUID();
    await role(
      'authenticated',
      () =>
        db.query(
          "insert into products(id,name,price,category,published) values($1,'Adminmöbel',125000,'Stolar',true)",
          [id],
        ),
      adminId,
    );
    await reserve(id);
    await expect(
      role(
        'authenticated',
        () => db.query("update products set stock=1,availability='available' where id=$1", [id]),
        adminId,
      ),
    ).rejects.toThrow('ACTIVE_RESERVATION');
    await expect(
      role(
        'authenticated',
        () => db.query('update products set price=100 where id=$1', [id]),
        adminId,
      ),
    ).rejects.toThrow('ACTIVE_RESERVATION');
    await role(
      'authenticated',
      () => db.query("update products set description='Uppdaterad beskrivning' where id=$1", [id]),
      adminId,
    );
  });
  it('blocks direct storage uploads even by admins, requiring server validation', async () => {
    await expect(
      role(
        'authenticated',
        () =>
          db.query(
            "insert into storage.objects(bucket_id,name) values('furniture-images','unsafe.svg')",
          ),
        adminId,
      ),
    ).rejects.toThrow('row-level security');
  });
});
