# RENOVA UF — verification report

Verified locally on 20 November 2026. No live site, Supabase project, Stripe account or customer records were created.

## Completed checks

| Check | Result |
| --- | --- |
| Dependency installation and lockfile generation | Passed |
| TypeScript (`tsc -b`, included in the production build) | Passed |
| ESLint (`npm run lint`) | Passed |
| Automated tests (`npm test`) | **60 tests passed in 7 files** |
| Pages Functions compilation and compiled-router smoke checks (`npm run test:functions`) | Passed |
| Production frontend (`npm run build`) | Passed; output is `dist` |
| Production browser preview | Passed; no production-page console errors observed |

The checks ran on Windows with Node 24.19.0. The project requires Node 24.15 or newer; Node 24 LTS is recommended. The checked-in lockfile records the tested dependency versions.

## Automated coverage

- Product cards, genuine product links and Swedish currency formatting.
- Cart persistence, duplicates, unavailable inventory, removal and clearing.
- Safe parsing of damaged browser storage and expiry/fingerprint checks for checkout attempts.
- A failed checkout followed by a page remount, with the product now reserved: the same request ID and customer/cart fingerprint are reused, so no second reservation is created.
- Disabled payments and the unconfigured admin interface, with no fake authentication.
- Accessible photo-comparison labels and continuously reversible clipping as the range control changes.
- Continuous restoration progress clamping, including invalid and out-of-range values.
- Forced WebGL failure: the illustrative scene uses its labelled local fallback, while a genuine product model is never replaced by the illustrative chair.
- File signatures, sizes, truncated models, external GLB resources and unsupported runtime codec extensions.
- Server origin/method/body validation, safe unconfigured responses, guest receipt tokens, signed raw Stripe webhook bodies and signature tampering.
- Both actual SQL migrations executed against embedded PostgreSQL (PGlite), with test stubs for Supabase's Auth and Storage infrastructure.
- Database reservation lifecycle, unavailable-stock rejection, repeated request/event handling, amount mismatch rollback, paid-state protection, expiry/restocking and reservation recovery.
- Anonymous/private-data isolation, admin-role escalation denial, service-only RPCs, reservation-edit protection and rejection of direct browser Storage uploads.

The compiled Pages Worker was also exercised using standard Request/Response APIs: configuration JSON, unknown API JSON 404 responses, method guards, unconfigured checkout/contact/admin-upload behavior and static fallback all passed. This verifies the generated router and bundle; it is not a test running in Cloudflare's deployed workerd runtime.

## Browser checks

The assembled site was inspected in the in-app browser at 1440×1000, 390×844 and 320×740 viewports. Checks covered:

- Homepage composition, locally loaded fonts, real WebGL chair, lighting and rotation controls.
- Mobile navigation opening, navigation to another page and automatic menu closure.
- Catalog empty state, navigation and direct page refresh.
- Process, About, Contact, Cart, admin setup, privacy, purchase information, invalid product, missing order reference and unknown-page states.
- Required contact fields, invalid email detection and truthful unavailable-service feedback; no test message was submitted to an external service.
- Manual restoration changes from 0 to 100 and back to 0 using keyboard controls.
- No horizontal page overflow in the inspected responsive states.
- Final production homepage and mobile navigation, including a production catalog refresh.

The host had reduced motion enabled. That mode was observed directly; full-motion scroll choreography was reviewed in source but was not manually exercised with the operating system preference disabled. The mathematical restoration transition and the manual alternative were tested. Device-size emulation is not a physical iPhone/Android touch or GPU benchmark.

During dependency installation, the running development server briefly reoptimized its dependencies and produced stale-cache hook errors. The final fresh production preview rendered successfully and had no production-origin console errors. Nonfatal WebGL driver precision warnings were seen in development. No fixed frame rate or Lighthouse score is claimed.

## Remaining account-connected verification

These are intentional activation steps, not completed tests:

1. Create the actual Supabase project, apply migrations, create the first authorized admin and configure both public and server credentials.
2. Test real Auth, Storage, product publication, persistent uploads and role revocation against that project.
3. Deploy to Cloudflare Pages and confirm the real platform's route fallback, security headers, environment values, Turnstile and Functions runtime.
4. Run the complete Stripe **test-mode** checklist in `docs/PAYMENTS.md`: concurrent buyers, price tampering, webhook delivery/replay, abandoned/cancelled sessions, asynchronous outcomes and recovery.
5. PGlite uses one connection. Competing reservation calls were tested sequentially; real simultaneous multi-client locking still needs the deployment test above.
6. Test maximum-size uploads and representative product models on target hardware. Only embedded GLB 2.0 with ordinary JPEG/PNG textures is accepted; Draco, Meshopt and KTX2 codec extensions are rejected.
7. Add genuine product, before/after and team photographs, and complete the actual merchant, privacy and consumer purchase information before enabling submissions/payments.
8. Configure and test receipt emails in Stripe. This project does not send its own transactional email, and does not implement automatic refunds or refund restocking.

## Performance and delivery notes

The 3D engine is a separate lazy-loaded chunk of approximately 1.26 MB minified / 358 KB gzip, so Vite reports its standard chunk-size advisory. Rendering uses capped pixel ratios, reduced mobile quality, offscreen pausing and reduced-motion alternatives. Fonts are locally hosted compressed WOFF2 files; there are no remote font/model/texture dependencies for the initial showroom.

The source archive excludes `node_modules`, `dist`, `.check`, caches, generated TypeScript build information and real environment/credential files. Install dependencies and run `npm run build` to recreate `dist`. No public deployment was performed.
