import { createClient } from '@supabase/supabase-js';
import Stripe from 'stripe';

/** Bindings are set in the Cloudflare Pages dashboard; none belong in VITE_ variables. */
export interface Env {
  SUPABASE_URL?: string;
  SUPABASE_SECRET_KEY?: string;
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;
  ORDER_TOKEN_SECRET?: string;
  SITE_URL?: string;
  CHECKOUT_ENABLED?: string;
  ALLOW_LIVE_PAYMENTS?: string;
  STRIPE_ENABLE_SWISH?: string;
  TURNSTILE_SECRET_KEY?: string;
  TURNSTILE_SITE_KEY?: string;
}
export type Context = { request: Request; env: Env };
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export function json(value: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      ...headers,
    },
  });
}
export function handler(method: string, run: (context: Context) => Promise<Response>) {
  return async (context: Context): Promise<Response> => {
    if (context.request.method !== method)
      return json({ error: 'Metoden stöds inte.' }, 405, { Allow: method });
    try {
      return await run(context);
    } catch (error) {
      if (error instanceof ApiError) return json({ error: error.message }, error.status);
      // Never log bodies, emails, tokens, upstream responses or secret-bearing errors.
      console.error(
        JSON.stringify({ event: 'api_failure', path: new URL(context.request.url).pathname }),
      );
      return json({ error: 'Tjänsten kunde inte slutföra begäran. Försök igen senare.' }, 503);
    }
  };
}
export function siteOrigin(env: Env): string {
  if (!env.SITE_URL) throw new ApiError(503, 'Tjänsten är inte aktiverad ännu.');
  const site = new URL(env.SITE_URL);
  if (
    site.protocol !== 'https:' &&
    !(['localhost', '127.0.0.1'].includes(site.hostname) && site.protocol === 'http:')
  ) {
    throw new ApiError(503, 'Tjänsten är inte aktiverad ännu.');
  }
  return site.origin;
}
export function assertOrigin(request: Request, env: Env) {
  if (request.headers.get('Origin') !== siteOrigin(env))
    throw new ApiError(403, 'Begäran kunde inte godkännas.');
}
export function databaseReady(env: Env) {
  try {
    return Boolean(
      env.SUPABASE_SECRET_KEY && new URL(env.SUPABASE_URL || '').protocol === 'https:',
    );
  } catch {
    return false;
  }
}
export function contactReady(env: Env) {
  try {
    return Boolean(
      databaseReady(env) && env.TURNSTILE_SECRET_KEY && env.TURNSTILE_SITE_KEY && siteOrigin(env),
    );
  } catch {
    return false;
  }
}
export function checkoutReady(env: Env) {
  return Boolean(
    contactReady(env) &&
    env.CHECKOUT_ENABLED === 'true' &&
    env.STRIPE_WEBHOOK_SECRET &&
    env.ORDER_TOKEN_SECRET &&
    env.ORDER_TOKEN_SECRET.length >= 32 &&
    (env.STRIPE_SECRET_KEY?.startsWith('sk_test_') ||
      (env.STRIPE_SECRET_KEY?.startsWith('sk_live_') && env.ALLOW_LIVE_PAYMENTS === 'true')),
  );
}
export function database(env: Env) {
  if (!databaseReady(env)) throw new ApiError(503, 'Tjänsten är inte aktiverad ännu.');
  return createClient(env.SUPABASE_URL!, env.SUPABASE_SECRET_KEY!, {
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });
}
export function stripeClient(env: Env) {
  if (!env.STRIPE_SECRET_KEY) throw new ApiError(503, 'Betalningar är inte aktiverade ännu.');
  return new Stripe(env.STRIPE_SECRET_KEY, {
    httpClient: Stripe.createFetchHttpClient(),
    maxNetworkRetries: 2,
  });
}
export async function limitedText(request: Request, maxBytes: number): Promise<string> {
  const size = request.headers.get('Content-Length');
  if (size && Number(size) > maxBytes) throw new ApiError(413, 'Begäran är för stor.');
  if (!request.body) return '';
  const reader = request.body.getReader();
  const parts: Uint8Array[] = [];
  let length = 0;
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > maxBytes) {
      await reader.cancel();
      throw new ApiError(413, 'Begäran är för stor.');
    }
    parts.push(value);
  }
  const all = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    all.set(part, offset);
    offset += part.length;
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(all);
}
export async function readJson(request: Request): Promise<unknown> {
  if (!(request.headers.get('Content-Type') || '').startsWith('application/json'))
    throw new ApiError(415, 'JSON krävs.');
  try {
    return JSON.parse(await limitedText(request, 16_384));
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError(400, 'Ogiltig begäran.');
  }
}
export function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new ApiError(400, 'Ogiltig begäran.');
  return value as Record<string, unknown>;
}
export const uuidPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function uuid(value: unknown): string {
  if (typeof value !== 'string' || !uuidPattern.test(value))
    throw new ApiError(400, 'Ogiltig referens.');
  return value.toLowerCase();
}
export function textField(value: unknown, min: number, max: number): string {
  if (typeof value !== 'string') throw new ApiError(400, 'Kontrollera uppgifterna i formuläret.');
  const text = value.trim();
  const hasControl = Array.from(text).some(
    (char) => char.charCodeAt(0) < 32 && !['\t', '\n', '\r'].includes(char),
  );
  if (text.length < min || text.length > max || hasControl) {
    throw new ApiError(400, 'Kontrollera uppgifterna i formuläret.');
  }
  return text;
}
export function emailField(value: unknown): string {
  const email = textField(value, 3, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new ApiError(400, 'Ange en giltig e-postadress.');
  return email;
}
export async function verifyHuman(token: unknown, request: Request, env: Env) {
  if (
    typeof token !== 'string' ||
    token.length < 1 ||
    token.length > 2048 ||
    !env.TURNSTILE_SECRET_KEY
  ) {
    throw new ApiError(400, 'Bekräfta att du är människa och försök igen.');
  }
  const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      secret: env.TURNSTILE_SECRET_KEY,
      response: token,
      remoteip: request.headers.get('CF-Connecting-IP') || undefined,
    }),
  });
  if (!response.ok) throw new ApiError(503, 'Verifieringen är tillfälligt otillgänglig.');
  const result = (await response.json()) as { success?: boolean; hostname?: string };
  if (!result.success || result.hostname !== new URL(siteOrigin(env)).hostname) {
    throw new ApiError(400, 'Verifieringen gick ut. Försök igen.');
  }
}
export async function sha256(value: string) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))),
  )
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}
async function tokenKey(env: Env) {
  if (!env.ORDER_TOKEN_SECRET || env.ORDER_TOKEN_SECRET.length < 32)
    throw new ApiError(503, 'Tjänsten är inte aktiverad ännu.');
  return crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(env.ORDER_TOKEN_SECRET),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify'],
  );
}
export async function orderToken(orderId: string, env: Env) {
  const signature = await crypto.subtle.sign(
    'HMAC',
    await tokenKey(env),
    new TextEncoder().encode(`renova-order:${orderId}`),
  );
  return Array.from(new Uint8Array(signature))
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}
export async function verifyOrderToken(orderId: string, token: unknown, env: Env) {
  if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token))
    throw new ApiError(404, 'Beställningen kunde inte hittas.');
  const signature = Uint8Array.from(token.match(/../g)!, (byte) => Number.parseInt(byte, 16));
  const ok = await crypto.subtle.verify(
    'HMAC',
    await tokenKey(env),
    signature,
    new TextEncoder().encode(`renova-order:${orderId}`),
  );
  if (!ok) throw new ApiError(404, 'Beställningen kunde inte hittas.');
}
