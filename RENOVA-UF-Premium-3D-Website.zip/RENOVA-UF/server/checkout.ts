import { ApiError, emailField, record, textField, uuid } from './runtime';
export type CheckoutInput = {
  requestId: string;
  items: { productId: string; quantity: number }[];
  customer: { name: string; email: string };
  turnstileToken: unknown;
};
export type ReservedOrder = {
  id: string;
  total: number;
  status: string;
  created_at: string;
  stripe_session_id: string | null;
  customer_email: string;
  items: { product_id: string; name: string; price: number; quantity: number }[];
};
export function validateCheckout(value: unknown): CheckoutInput {
  const body = record(value);
  const customer = record(body.customer);
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 10)
    throw new ApiError(400, 'Välj mellan en och tio möbler.');
  const items = body.items
    .map((value) => {
      const item = record(value);
      if (
        !Number.isInteger(item.quantity) ||
        Number(item.quantity) < 1 ||
        Number(item.quantity) > 10
      ) {
        throw new ApiError(400, 'Ogiltigt antal.');
      }
      return { productId: uuid(item.productId), quantity: Number(item.quantity) };
    })
    .sort((a, b) => a.productId.localeCompare(b.productId));
  if (new Set(items.map((item) => item.productId)).size !== items.length)
    throw new ApiError(400, 'En möbel kan bara förekomma en gång.');
  return {
    requestId: uuid(body.requestId),
    items,
    customer: { name: textField(customer.name, 2, 120), email: emailField(customer.email) },
    turnstileToken: body.turnstileToken,
  };
}
