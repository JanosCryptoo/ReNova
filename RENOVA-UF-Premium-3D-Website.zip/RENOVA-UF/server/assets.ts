import { ApiError } from './runtime';
export function validateAsset(
  data: Uint8Array,
  kind: unknown,
): { bucket: string; extension: string; mime: string } {
  if (kind === 'image') {
    if (data.length < 16 || data.length > 8 * 1024 * 1024)
      throw new ApiError(400, 'Bilden får vara högst 8 MB.');
    let type: { extension: string; mime: string } | undefined;
    const ascii = (start: number, end: number) => new TextDecoder().decode(data.slice(start, end));
    if (data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff)
      type = { extension: 'jpg', mime: 'image/jpeg' };
    else if ([137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => data[index] === byte))
      type = { extension: 'png', mime: 'image/png' };
    else if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP')
      type = { extension: 'webp', mime: 'image/webp' };
    if (!type)
      throw new ApiError(400, 'Välj en riktig JPEG-, PNG- eller WebP-bild. SVG stöds inte.');
    return { bucket: 'furniture-images', ...type };
  }
  if (kind !== 'model' || data.length < 24 || data.length > 20 * 1024 * 1024)
    throw new ApiError(400, 'Välj en GLB-modell på högst 20 MB.');
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (
    view.getUint32(0, true) !== 0x46546c67 ||
    view.getUint32(4, true) !== 2 ||
    view.getUint32(8, true) !== data.length ||
    view.getUint32(16, true) !== 0x4e4f534a
  ) {
    throw new ApiError(400, 'Filen är inte en giltig GLB 2.0-modell.');
  }
  const jsonLength = view.getUint32(12, true);
  if (jsonLength > 2 * 1024 * 1024 || jsonLength + 20 > data.length)
    throw new ApiError(400, 'Modellens beskrivning är ogiltig eller för stor.');
  let model: unknown;
  try {
    model = JSON.parse(
      new TextDecoder('utf-8', { fatal: true }).decode(data.slice(20, 20 + jsonLength)),
    );
  } catch {
    throw new ApiError(400, 'Modellens beskrivning kunde inte läsas.');
  }
  // Keep models entirely self-contained. Remote textures/buffers can leak visitor IPs or track them.
  const queue: unknown[] = [model];
  let checked = 0;
  while (queue.length) {
    const value = queue.pop();
    if (++checked > 100000) throw new ApiError(400, 'Modellen är för komplex.');
    if (value && typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) {
        const codecs = [
          'KHR_draco_mesh_compression',
          'EXT_meshopt_compression',
          'KHR_texture_basisu',
        ];
        if (codecs.includes(key) || (typeof child === 'string' && codecs.includes(child)))
          throw new ApiError(
            400,
            'Exportera GLB utan Draco, Meshopt eller KTX2. Använd inbäddade JPEG-/PNG-texturer.',
          );
        if (key.toLowerCase() === 'uri')
          throw new ApiError(
            400,
            'Modellen måste innehålla alla material och texturer i samma GLB-fil.',
          );
        if (child && typeof child === 'object') queue.push(child);
      }
    }
  }
  if (
    !model ||
    typeof model !== 'object' ||
    !('asset' in model) ||
    !model.asset ||
    typeof model.asset !== 'object' ||
    !('version' in model.asset) ||
    model.asset.version !== '2.0'
  ) {
    throw new ApiError(400, 'Modellen saknar GLTF 2.0-information.');
  }
  return { bucket: 'furniture-models', extension: 'glb', mime: 'model/gltf-binary' };
}
