# RENOVA UF — Premium 3D Website

**Från gammalt till nytt.** A Swedish furniture-restoration storefront for RENOVA UF, Eskilstuna, built with React, TypeScript, Vite, React Router, Three.js, React Three Fiber, Drei, GSAP, Motion, Lenis and Tailwind CSS. Deployment targets **Cloudflare Pages**, with optional Supabase and Stripe integrations.

The site runs without backend credentials. Its chair is a genuine procedural 3D model, clearly labelled as an illustration. The product catalog, photographic restoration gallery and team gallery start empty because no genuine owner photographs or inventory were supplied. There are no invented products, prices, team members, reviews or restoration projects.

This is a complete source project. No external account has been configured or live payment enabled by unpacking it. See [TEST-REPORT.md](TEST-REPORT.md) for the checks actually performed and the remaining account-connected verification.

## Start locally

1. Extract `RENOVA-UF-Premium-3D-Website.zip`.
2. Open a terminal in the extracted `RENOVA-UF` folder, the folder containing `package.json`.
3. Install Node.js **24.15 or newer (Node 24 LTS recommended)**. Use a maintained release compatible with the lockfile. Check `node --version` and `npm --version`.
4. Install and start:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite, normally `http://127.0.0.1:5173`.

No environment variables are needed for the initial showroom. To connect the public Supabase client later, copy `.env.example` to `.env.local`, fill in its two public values and restart Vite. Never add a secret/service key to a `VITE_` variable.

On Windows, if PowerShell blocks the `npm.ps1` wrapper, use `npm.cmd install` and `npm.cmd run dev`. After the first install, `npm ci` reproduces the committed lockfile without changing dependency versions.

### Check and build

```bash
npm run typecheck
npm run lint
npm test
npm run build
npm run preview
```

`npm run build` first checks TypeScript and then writes the production frontend to `dist`. `npm run preview` serves that build, normally at `http://127.0.0.1:4173`.

| Script                   | Purpose                                                     |
| ------------------------ | ----------------------------------------------------------- |
| `npm run dev`            | Local Vite frontend with live reload                        |
| `npm run typecheck`      | TypeScript validation of frontend and Functions sources     |
| `npm run lint`           | ESLint checks                                               |
| `npm run test:functions` | Compile Pages Functions and test compiled routing           |
| `npm run format`         | Format the maintainable source                              |
| `npm test`               | Vitest automated tests                                      |
| `npm run build`          | TypeScript check plus production frontend build into `dist` |
| `npm run preview`        | Serve the built frontend locally                            |

The lockfile records the resolved compatible package versions. `@supabase/supabase-js` serves both public frontend data access and server operations; only the server receives a secret key. The `stripe` SDK is used by Pages Functions with its fetch/Web Crypto-compatible adapters, not by the browser bundle. Database tests use `@electric-sql/pglite` as a development dependency; it is not a production database or a replacement for Supabase. Installing development dependencies is necessary for the TypeScript/Vite build and tests.

**Vite does not execute Cloudflare Pages Functions.** Local preview validates the interface, navigation and 3D experience. Its `/api` requests are deliberately treated as unavailable, so contact submission and checkout remain disabled. If Supabase is configured, direct catalog reads and Supabase Auth can work locally, but server uploads and payments still need the Pages runtime. A plain static server is not a full backend test.

## What is included

- A Swedish homepage with the exact brand palette, local editorial fonts, interactive 3D chair, lighting, drag/touch controls and camera motion.
- A scroll-controlled restoration of the same chair geometry, with continuous material changes, fading wear, reverse scrolling and a manual reduced-motion alternative.
- An accessible before/after photo divider that becomes populated when genuine restoration images are added.
- Catalog search, categories and sorting; product details, galleries and optional uploaded GLB models; a persistent local cart; checkout and verified order-status pages.
- Process, About, Contact, privacy, purchase-information and not-found pages.
- A protected `/admin` workspace for products, images, inventory, featured products, restoration galleries, company photographs, orders and contact messages.
- Optional Supabase data services, database migrations, Row Level Security, storage policies and bucket setup helper.
- Optional Stripe Checkout Pages Functions, signed webhook verification, transactional stock reservations, idempotent handling and admin recovery.
- Responsive layouts, keyboard interactions, reduced-motion support, lazy 3D loading, limited rendering resolution, offscreen pausing and a WebGL fallback illustration.
- Automated tests, build configuration and deployment documentation.

The Instagram section links to the supplied `@uf_renova` account. It does not fabricate a feed or load a tracking embed. Card payments are prepared; Swish remains optional and depends on the Stripe account's eligibility.

## Routes

| Address           | Page                                                  |
| ----------------- | ----------------------------------------------------- |
| `/`               | Startsida                                             |
| `/mobler`         | Våra möbler                                           |
| `/mobler/:id`     | Product detail                                        |
| `/process`        | Vår process                                           |
| `/om-oss`         | Om oss                                                |
| `/kontakt`        | Kontakt                                               |
| `/varukorg`       | Shopping cart and checkout entry                      |
| `/bestallning`    | Verified order status; requires an opaque signed link |
| `/admin`          | Administrator workspace                               |
| `/integritet`     | Privacy information to complete before activation     |
| `/kopinformation` | Purchase information to complete before activation    |

## Deploy to Cloudflare Pages from GitHub

This project uses the requested Pages platform. It does not require Vercel, Netlify, Lovable, an always-on Node server, or a proprietary website builder.

### 1. Put the source on GitHub

Create a new empty GitHub repository. You can publish the extracted folder with GitHub Desktop, or use these commands after replacing the remote address with your own repository:

```bash
git init
git add .
git status
git commit -m "Add RENOVA UF website"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPOSITORY.git
git push -u origin main
```

Review `git status` before committing. Include `package-lock.json`, `public`, `src`, `functions` and `supabase`. Do not upload `node_modules`, real `.env.local`/`.dev.vars` files, credentials or caches. The included `.gitignore` covers those files. Do not upload the ZIP itself as the website's source file.

### 2. Create the Pages project

In the Cloudflare dashboard, open **Workers & Pages → Create application → Pages → Connect to Git / Import an existing Git repository**. Select GitHub, authorize the intended repository and choose its production branch. Cloudflare's wording may change slightly; select the **Pages** Git integration. See the [official Git integration guide](https://developers.cloudflare.com/pages/get-started/git-integration/).

Use these settings:

| Setting                | Value                                                                       |
| ---------------------- | --------------------------------------------------------------------------- |
| Framework preset       | React / Vite if offered, or None with the explicit values below             |
| Production branch      | `main`, or the branch you chose                                             |
| Root directory         | The folder containing `package.json`; blank if it is at the repository root |
| Build command          | `npm run build`                                                             |
| Build output directory | `dist`                                                                      |
| Build Node.js version  | Node 24 LTS, at least `24.15.0` (set `NODE_VERSION=24`)                     |

If the repository contains an outer `RENOVA-UF` folder, set the root directory to `RENOVA-UF`. Configure the build's `NODE_VERSION` setting if needed. Keep `functions/` at that project root, beside `package.json`, rather than moving it into `dist`. Git-based Pages deployment discovers and compiles those Functions separately from Vite's frontend build. See [Pages build configuration](https://developers.cloudflare.com/pages/configuration/build-configuration/) and [Functions setup](https://developers.cloudflare.com/pages/functions/get-started/).

Deploy once with **no backend values** to verify the showroom. A successful deployment supplies the actual `*.pages.dev` address. This source package does not contain a claimed live deployment URL.

### 3. Verify routing

`public/_routes.json` is copied into `dist` and limits Function invocation to `/api/*`. The API catchall returns JSON errors for unknown API routes. Website paths use Cloudflare Pages' native SPA fallback: without a top-level `404.html`, Pages serves `index.html` for unmatched frontend paths and React Router selects the page. The application's not-found view is a React route.

**Do not add a top-level `404.html` or a global `/* /index.html 200` rewrite.** A catchall rewrite can interfere with API routing. Keep the API routes and SPA fallback distinct. See [Serving Pages](https://developers.cloudflare.com/pages/configuration/serving-pages/) and [Functions routing](https://developers.cloudflare.com/pages/functions/routing/).

After deployment, open and refresh `/mobler`, `/process`, `/om-oss`, `/kontakt` and `/admin` directly. Request `/api/config`: it should return JSON with disabled capabilities until configured. An unknown `/api/not-a-route` should return a JSON 404, not the homepage.

### 4. Environment settings and previews

Set public build variables and server runtime variables/secrets in your Pages project's settings. Use **Production** and **Preview** environments deliberately; production credentials must not be copied into a general development preview. Rebuild/redeploy after changing configuration. Build-time `VITE_` values are compiled into the JavaScript sent to visitors. See [Pages bindings and environment settings](https://developers.cloudflare.com/pages/functions/bindings/).

For a full API rehearsal, create a Git branch, deploy it as a Pages preview, and use a **separate test Supabase project and Stripe test credentials**. Choose one preview branch address for testing, set its exact HTTPS origin in `SITE_URL`, and use that same address for Turnstile and the Stripe webhook. Redeploy with those settings. Access the selected origin consistently: another preview alias or the production URL will fail the origin check. Cloudflare documents [preview deployments](https://developers.cloudflare.com/pages/configuration/preview-deployments/); preview URLs are public unless you add access restrictions. Do not expose a preview's personal data or secrets.

This is the documented full-runtime test path. No Cloudflare CLI installation or Wrangler configuration is required by this project. `.dev.vars.example` documents the runtime variables for developers who later use a compatible local Pages emulator; Vite does not read that file or start such an emulator.

### 5. Add a custom domain

Open your Pages project → **Custom domains → Set up a domain** and follow Cloudflare's DNS instructions. Add the domain through Pages first. Apex domains require the corresponding Cloudflare zone; a subdomain can use the instructed CNAME. Wait for domain verification and HTTPS to be active. See [Cloudflare custom domains](https://developers.cloudflare.com/pages/configuration/custom-domains/).

When switching to the final domain, update `SITE_URL`, Supabase Auth Site URL/allowed redirect URLs, Turnstile allowed hostnames and the Stripe webhook destination. Update the webhook signing secret if the destination changes. Redeploy and test again. Use a consistent canonical origin for checkout. If you use a custom Supabase domain, update the CSP `img-src` and `connect-src` hosts in `public/_headers`; the supplied policy allows standard `*.supabase.co` URLs.

## Connect Supabase later

No frontend redesign is needed. Start with a new Supabase project dedicated to RENOVA UF and use a separate project for tests.

1. Open the new project's SQL Editor. Apply these files **in order**, once:

   ```text
   supabase/migrations/20261120000000_renova_initial.sql
   supabase/migrations/20261120000001_reservation_recovery.sql
   ```

   They create products, product images, restorations, company images, orders, order items, admin roles, contact messages, reservation/event infrastructure, relationships, indexes, explicit grants and Row Level Security. They target a fresh project; do not run them blindly against an unrelated existing database. Do not expose the `private` schema through the Data API. Read [docs/SECURITY.md](docs/SECURITY.md).

2. Configure the frontend's public build variables:

   ```env
   VITE_SUPABASE_URL=
   VITE_SUPABASE_PUBLISHABLE_KEY=
   ```

   Get the project's HTTPS URL and **publishable** key from its dashboard. Never use `sb_secret_...` or a legacy `service_role` key here. For local frontend development put these values in ignored `.env.local`; for Pages put them in its build environment.

3. Configure the server runtime:

   ```env
   SUPABASE_URL=
   SUPABASE_SECRET_KEY=
   SITE_URL=
   ```

   `SUPABASE_URL` must be the same project as the frontend. Store `SUPABASE_SECRET_KEY` as a Cloudflare secret; it belongs only on the server. `SITE_URL` is the exact HTTPS website origin with no path. These runtime values are needed for protected media upload even when Stripe and the contact form remain off.

4. Create the two **public marketing-asset buckets**. Either use the Supabase Storage dashboard with the settings below, or temporarily set `SUPABASE_URL` and `SUPABASE_SECRET_KEY` in a trusted local shell's environment and run:

   ```bash
   node supabase/storage-setup.mjs
   ```

   | Bucket             | Public | Allowed MIME types                      | Maximum file size |
   | ------------------ | ------ | --------------------------------------- | ----------------- |
   | `furniture-images` | Yes    | `image/jpeg`, `image/png`, `image/webp` | 8 MiB             |
   | `furniture-models` | Yes    | `model/gltf-binary`                     | 20 MiB            |

   The helper only creates/updates these named buckets. Do not place the secret in a command argument or committed file. The SQL policies intentionally deny direct browser uploads; `/api/admin/upload` verifies the current administrator and file contents, then writes to Storage. Public asset URLs remain readable even if a related database record is unpublished, so upload only non-sensitive content you intend to share.

5. Create each intended administrator under **Supabase Authentication → Users**. Use individual accounts, configure Auth's Site URL and allowed redirects, and disable public signups for this private team if appropriate. Copy the actual Auth user's UUID and run the following in SQL Editor, replacing the placeholder:

   ```sql
   insert into public.admin_roles (user_id, role)
   values ('REPLACE-WITH-ACTUAL-AUTH-USER-UUID', 'admin');
   ```

   The website does not allow users to grant themselves roles. A signed-in account without that row cannot administer the store. Account/password recovery is handled through Supabase; no fake login or shared password is included.

6. Redeploy. Sign in at `/admin`, create a product as a draft, save it, add actual product photographs, then publish it. Enter prices in SEK; the database stores integer öre. Set inventory deliberately, normally `1` for a unique piece. Use the category field to choose an existing category or create another. Set dimensions, condition, description and featured status. Publish real before/after pairs from the restoration tab and company/team images from the company tab.

7. Reload in a private browser and verify that published content appears. Change it in Admin and confirm the change persists. Test a non-admin account and anonymous requests: they must not write content, read private orders/messages, upload files or add roles. Run Supabase's security advisors. Review the account-connected test checklist in [docs/SECURITY.md](docs/SECURITY.md) and [docs/PAYMENTS.md](docs/PAYMENTS.md).

The application checks admin roles in the UI, in upload/reconciliation Functions and through database RLS. RLS is the security boundary for direct database operations; do not disable it to solve a permissions error.

## Activate the contact form

The contact form validates name, email and message, but does not pretend to send when disconnected. Visitors can still follow the supplied Instagram link.

1. Complete the owner/contact and privacy content before collecting real messages.
2. Configure the Supabase server values above.
3. Create a Cloudflare Turnstile widget for the exact testing or production hostname.
4. Add public `TURNSTILE_SITE_KEY` and secret `TURNSTILE_SECRET_KEY` to Pages runtime settings.
5. Redeploy and submit a real test message. Check `/admin` → **Meddelanden** for persistence and confirm validation and challenge errors.

The public widget key is delivered through `/api/config`; it is not a secret. Successful submissions are saved to `contact_messages`, visible only to administrators. **The website does not send an email notification**. Review the admin inbox or add a separately configured notification service later.

## Prepare Stripe, then test before taking payment

Keep **`CHECKOUT_ENABLED=false`** until the backend, webhook, genuine inventory, seller identity, purchase terms and privacy information are complete. Keep **`ALLOW_LIVE_PAYMENTS=false`** during all test work. Merely setting keys does not authorize or prove a live-ready store.

1. Use an eligible business Stripe account and start in test mode.
2. Configure the Supabase and Turnstile runtime settings above.
3. Set `STRIPE_SECRET_KEY` to a test key, generate a cryptographically random `ORDER_TOKEN_SECRET` of at least 32 characters, and keep it stable. Store both as Cloudflare secrets.
4. Add a Stripe webhook destination at `https://YOUR-TEST-ORIGIN/api/stripe-webhook`. Subscribe to `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed` and `checkout.session.expired`.
5. Store that destination's signing secret as `STRIPE_WEBHOOK_SECRET`. Match test/live mode and origin. An unrelated endpoint's or CLI-forwarding secret will not work.
6. On the **test deployment only**, set `CHECKOUT_ENABLED=true`, leave `ALLOW_LIVE_PAYMENTS=false`, redeploy and run all tests in [docs/PAYMENTS.md](docs/PAYMENTS.md). Use private test fixtures; do not publish invented merchandise in production.
7. Check two simultaneous attempts to buy a stock-one product, authoritative database prices, webhook signatures, replay handling, expired/canceled sessions, delayed notifications and failed requests. Verify one sale cannot release stock afterward. Configure and test Stripe receipts if you want email receipts.
8. Use Admin → Beställningar → **Kontrollera reservation** to reconcile stale reservations against Stripe. A local timer never releases possibly paid stock. Do not manually restock unresolved payments. The detailed recovery protocol and refund responsibilities are in [docs/PAYMENTS.md](docs/PAYMENTS.md).
9. To offer Swish, confirm eligibility/availability in the account and enable it in Stripe, then set `STRIPE_ENABLE_SWISH=true` and test it. It is not guaranteed merely because the website is Swedish. See [Stripe's Swish documentation](https://docs.stripe.com/payments/swish).
10. Only after the account-connected tests and owner content review pass, configure production/live keys and its separate webhook, explicitly set `ALLOW_LIVE_PAYMENTS=true`, enable checkout and perform a controlled owner-approved live verification.

All prices and stock are checked on the server. PostgreSQL row locks reserve inventory before Stripe Checkout opens. Verified webhook events update stock and orders atomically and idempotently. A browser return URL never marks an order paid. Guest order links contain a signed token and display only status and total; treat those links as private.

The prepared sales flow assumes **pickup in Eskilstuna by agreement**. It does not collect delivery addresses, calculate shipping or automate refunds. Confirm this arrangement with the owner before enabling purchases. Stripe processes card information on its own hosted page; this site's forms do not collect card numbers.

## Environment reference

| Name                            | Where                                    | Needed for                               |
| ------------------------------- | ---------------------------------------- | ---------------------------------------- |
| `VITE_SUPABASE_URL`             | Public frontend build                    | Catalog, Auth, admin data                |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Public frontend build                    | Catalog, Auth, admin data                |
| `SUPABASE_URL`                  | Pages runtime variable                   | Server database operations               |
| `SUPABASE_SECRET_KEY`           | Pages runtime **secret**                 | Uploads, messages, orders                |
| `SITE_URL`                      | Pages runtime variable                   | Exact origin checks and Stripe redirects |
| `TURNSTILE_SITE_KEY`            | Pages runtime variable, public           | Contact/checkout widget                  |
| `TURNSTILE_SECRET_KEY`          | Pages runtime **secret**                 | Contact/checkout verification            |
| `STRIPE_SECRET_KEY`             | Pages runtime **secret**                 | Stripe Checkout and recovery             |
| `STRIPE_WEBHOOK_SECRET`         | Pages runtime **secret**                 | Stripe signature verification            |
| `ORDER_TOKEN_SECRET`            | Pages runtime **secret**, 32+ characters | Signed guest status/cancel links         |
| `CHECKOUT_ENABLED`              | Pages runtime variable, default `false`  | Explicit checkout activation             |
| `ALLOW_LIVE_PAYMENTS`           | Pages runtime variable, default `false`  | Additional guard for live Stripe keys    |
| `STRIPE_ENABLE_SWISH`           | Pages runtime variable, default `false`  | Optional eligible Swish payments         |

The examples contain no working credentials. `.env.example` is for public Vite values. `.dev.vars.example` is a runtime reference and may be copied to ignored `.dev.vars` only when intentionally using a local Pages runtime. Changing `.env.local` requires restarting Vite; changing a deployed build value requires rebuilding. No secret variable should ever begin with `VITE_`.

## Source map

```text
RENOVA-UF/
├── public/
│   ├── fonts/              Local typefaces and license notices
│   ├── icons/              Local favicon
│   ├── models/             Authored fallback illustration
│   ├── textures/           Procedural texture documentation
│   ├── _headers            Static response security/cache headers
│   └── _routes.json        Pages Functions routing
├── src/
│   ├── components/
│   │   ├── animations/     GSAP/Lenis/Motion integration
│   │   ├── before-after/   Accessible photographic divider
│   │   ├── layout/         Header, menu and footer
│   │   ├── products/       Catalog components and empty state
│   │   └── three/          Chair geometry, materials and restoration
│   ├── hooks/              Catalog and service capability hooks
│   ├── pages/              Customer pages and Admin
│   ├── services/           Supabase, API and upload boundaries
│   ├── lib/                Formatting and cart logic
│   ├── styles/             Visual design and admin layout
│   └── types/              Shared data types
├── functions/
│   ├── _lib/               Server validation and payment helpers
│   └── api/                Config, contact, checkout, webhook, admin
├── supabase/
│   ├── migrations/         Schema, RLS and recovery transactions
│   └── storage-setup.mjs    Optional bucket setup helper
├── tests/                  Additional automated tests
├── docs/                   Security and payment operations
├── .env.example
├── .dev.vars.example
├── ASSETS.md
├── TEST-REPORT.md
├── package.json
├── package-lock.json
├── vite.config.ts
└── tsconfig.json
```

## Owner content and launch checklist

- Add real furniture names, prices, condition, dimensions, stock and photographs. Publish only products you can sell.
- Add matched authentic before/after photographs; the supplied 3D demonstration is illustrative and must remain labelled that way.
- Add authorized company/team photographs. The current site intentionally leaves that space empty.
- Complete `src/pages/Information.tsx` with the actual seller identity, support contact, full sale/return/complaint terms, privacy responsibilities and retention details appropriate to the business. The present copy explicitly says those details are incomplete.
- Confirm pickup arrangements, receipts, refunds and how customer inquiries will be answered. Do not activate the contact form before its privacy information is complete.
- Keep checkout off until genuine content and the account-connected security/payment tests are complete. No source-only test certifies a merchant's live account.
- Test the configured deployment on your intended mobile devices, keyboard and reduced-motion settings. Performance depends on device/GPU; no fixed frame rate is promised.
- Keep credentials outside Git, restrict account access, keep backups and monitor failed payment notifications.

## Troubleshooting

**Everything looks complete but there are no products:** this is intentional before Supabase and real published inventory are added. Draft products appear only in Admin.

**Admin says setup is required:** check both public `VITE_SUPABASE_*` values, then restart/rebuild. A server secret cannot replace a publishable key.

**An account can log in but cannot administer:** check the exact Auth UUID in `public.admin_roles`. Never relax RLS or put role assignments in editable user metadata.

**Uploads fail:** confirm the Pages runtime is actually running, server Supabase values point to the same project, the buckets exist, `SITE_URL` matches the browser origin, and the file meets the size/type rules. Vite preview alone cannot handle uploads. Models must be self-contained GLB 2.0 files with no `uri` references.

**Contact or checkout stays disabled:** `/api/config` reports capabilities conservatively. Check server variables and Turnstile setup. Test checkout needs a `sk_test_` key, webhook secret, sufficiently long order-token secret and explicit checkout activation. Live keys additionally require `ALLOW_LIVE_PAYMENTS=true`.

**A direct page refresh fails:** verify `dist` is the selected output, keep `index.html`, do not add a root `404.html`, and remove conflicting catchall rewrite rules.

**3D is unavailable:** the site shows a labelled local illustration; navigation and commerce remain usable. Try a WebGL-capable browser with hardware acceleration. Reduced-motion settings intentionally change animation behavior.

**A reservation remains locked:** inspect its Stripe status and use the authenticated reconciliation control. See [docs/PAYMENTS.md](docs/PAYMENTS.md); do not solve it by blindly increasing stock.

Asset provenance and licensing are documented in [ASSETS.md](ASSETS.md). Actual verification results and limitations are in [TEST-REPORT.md](TEST-REPORT.md).

## Compiling and smoke-testing Pages Functions

`npm run test:functions` uses the official `@cloudflare/pages-functions` compiler, writes a temporary Worker to `.check/functions/index.js`, then checks the compiled API routing and safe unconfigured responses using standard Fetch APIs. `.check/` is ignored and excluded from the ZIP. This is not a hosted Cloudflare runtime test. Git-connected Pages builds its `functions/` directory automatically; keep the dashboard build command as `npm run build`.

### Product model format

Optional product models must be ordinary GLB 2.0 with all geometry and JPEG/PNG textures embedded. Export without Draco, Meshopt or KTX2 compression; these codec extensions are explicitly rejected to avoid runtime CDN/decoder requirements. Keep models lightweight through sensible polygon counts and image dimensions. The illustrative hero is procedural and needs no model upload.
