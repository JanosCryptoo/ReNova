RENOVA UF chair textures

The chair's worn and restored walnut textures are generated locally from deterministic mathematical grain in src/components/three/materials.ts. They are original artwork supplied with this source, have no external asset dependencies, and need no licensing attribution.

Texture size is 512 x 512 on desktop and 256 x 256 on coarse-pointer devices. A standard physically based material blends between both textures on the SAME furniture geometry. Original scratches disappear continuously as restoration progress increases. No genuine RENOVA restoration project is implied.

public/models/chair-fallback.svg is an original illustrated fallback, used only for loading or unavailable WebGL. The normal hero is procedural Three.js geometry, not the SVG. Genuine uploaded product models are loaded as GLB through Drei's GLTF loader and are never replaced by the illustrative chair.
