import { createContext, useContext, useState, type ReactNode } from 'react';
import type { CartItem, Product } from '../types';
import { parseCart } from '../lib/cart';
type CartContextValue = {
  items: CartItem[];
  add: (p: Product) => void;
  remove: (id: string) => void;
  clear: () => void;
  notice: string;
  dismiss: () => void;
};
const CartContext = createContext<CartContextValue | null>(null);
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      return parseCart(localStorage.getItem('renova-cart-v1'));
    } catch {
      return [];
    }
  });
  const [notice, setNotice] = useState('');
  function update(next: CartItem[]) {
    setItems(next);
    try {
      localStorage.setItem('renova-cart-v1', JSON.stringify(next));
    } catch {
      /* Browsing still works without storage. */
    }
  }
  function add(p: Product) {
    if (p.stock < 1 || p.availability !== 'available') {
      setNotice('Möbeln är inte tillgänglig just nu.');
      return;
    }
    if (items.some((i) => i.productId === p.id)) {
      setNotice('Möbeln finns redan i din varukorg.');
      return;
    }
    update([...items, { productId: p.id, quantity: 1 }]);
    setNotice(`${p.name} har lagts i din varukorg.`);
  }
  return (
    <CartContext.Provider
      value={{
        items,
        add,
        remove: (id) => update(items.filter((i) => i.productId !== id)),
        clear: () => update([]),
        notice,
        dismiss: () => setNotice(''),
      }}
    >
      {children}
    </CartContext.Provider>
  );
}
// This hook deliberately shares the provider module.
export function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('CartProvider saknas');
  return value;
}
