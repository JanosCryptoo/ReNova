import { useId, useState } from 'react';
import { MoveHorizontal } from 'lucide-react';
export default function BeforeAfter({
  before,
  after,
  title,
}: {
  before: string;
  after: string;
  title: string;
}) {
  const [position, setPosition] = useState(50);
  const id = useId();
  return (
    <figure className="comparison">
      <div className="comparison-stage">
        <img src={after} alt={`${title} efter restaurering`} loading="lazy" />
        <div className="comparison-before" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}>
          <img src={before} alt={`${title} före restaurering`} loading="lazy" />
        </div>
        <span className="comparison-label before-label">Före</span>
        <span className="comparison-label after-label">Efter</span>
        <div className="comparison-line" style={{ left: `${position}%` }}>
          <span>
            <MoveHorizontal size={22} />
          </span>
        </div>
        <label className="sr-only" htmlFor={id}>
          Dra för att jämföra {title} före och efter restaurering
        </label>
        <input
          id={id}
          type="range"
          min="0"
          max="100"
          value={position}
          onChange={(e) => setPosition(Number(e.target.value))}
          aria-valuetext={`${position} procent före restaurering`}
        />
      </div>
      <figcaption>
        {title}
        <span>Dra reglaget eller använd piltangenterna.</span>
      </figcaption>
    </figure>
  );
}
