import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
export default function MotionSystem() {
  const { pathname } = useLocation();
  useEffect(() => {
    const query = matchMedia('(prefers-reduced-motion: reduce)');
    let cleanup = () => {};
    const setup = () => {
      cleanup();
      if (query.matches) return;
      const lenis = new Lenis({
        duration: 1.05,
        smoothWheel: true,
        syncTouch: false,
        anchors: true,
      });
      lenis.on('scroll', ScrollTrigger.update);
      const tick = (time: number) => lenis.raf(time * 1000);
      gsap.ticker.add(tick);
      cleanup = () => {
        gsap.ticker.remove(tick);
        lenis.destroy();
      };
    };
    setup();
    query.addEventListener('change', setup);
    return () => {
      cleanup();
      query.removeEventListener('change', setup);
    };
  }, []);
  useEffect(() => {
    if (!location.hash) window.scrollTo({ top: 0, behavior: 'instant' });
    const heading = document.querySelector<HTMLElement>('#main');
    heading?.focus({ preventScroll: true });
    const timer = setTimeout(() => ScrollTrigger.refresh(), 350);
    return () => clearTimeout(timer);
  }, [pathname]);
  return null;
}
