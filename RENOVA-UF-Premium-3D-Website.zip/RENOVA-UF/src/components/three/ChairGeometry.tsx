import { useEffect, useMemo } from 'react';
import * as THREE from 'three';

function roundedRectangle(width: number, height: number, radius: number) {
  const x = -width / 2,
    y = -height / 2,
    s = new THREE.Shape();
  s.moveTo(x + radius, y);
  s.lineTo(x + width - radius, y);
  s.quadraticCurveTo(x + width, y, x + width, y + radius);
  s.lineTo(x + width, y + height - radius);
  s.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  s.lineTo(x + radius, y + height);
  s.quadraticCurveTo(x, y + height, x, y + height - radius);
  s.lineTo(x, y + radius);
  s.quadraticCurveTo(x, y, x + radius, y);
  return s;
}

function sculptedSeat(lowDetail = false) {
  const shape = roundedRectangle(1.53, 1.37, 0.24);
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: 0.085,
    bevelEnabled: true,
    bevelSize: 0.052,
    bevelThickness: 0.035,
    bevelSegments: lowDetail ? 2 : 3,
    curveSegments: lowDetail ? 10 : 20,
    steps: 2,
  });
  geometry.rotateX(-Math.PI / 2);
  const vertices = geometry.attributes.position;
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i),
      z = vertices.getZ(i);
    vertices.setY(i, vertices.getY(i) + 0.045 * (x * x + z * z));
  }
  geometry.computeVertexNormals();
  return geometry;
}

function curvedBack(lowDetail = false) {
  const geometry = new THREE.BoxGeometry(
    1.9,
    0.41,
    0.14,
    lowDetail ? 24 : 48,
    lowDetail ? 3 : 6,
    3,
  );
  const vertices = geometry.attributes.position;
  const core = new THREE.Vector3(),
    normal = new THREE.Vector3();
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i),
      y = vertices.getY(i),
      z = vertices.getZ(i);
    core.set(
      THREE.MathUtils.clamp(x, -0.9, 0.9),
      THREE.MathUtils.clamp(y, -0.155, 0.155),
      THREE.MathUtils.clamp(z, -0.02, 0.02),
    );
    normal.set(x, y, z).sub(core).normalize().multiplyScalar(0.05);
    const px = core.x + normal.x;
    vertices.setXYZ(i, px, core.y + normal.y - px * px * 0.09, core.z + normal.z + px * px * 0.32);
  }
  const uv = geometry.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getY(i), uv.getX(i));
  geometry.computeVertexNormals();
  return geometry;
}

function Beam({
  from,
  to,
  radiusTop,
  radiusBottom,
  material,
}: {
  from: [number, number, number];
  to: [number, number, number];
  radiusTop: number;
  radiusBottom: number;
  material: THREE.Material;
}) {
  const { middle, rotation, length } = useMemo(() => {
    const start = new THREE.Vector3(...from),
      end = new THREE.Vector3(...to);
    const delta = end.clone().sub(start);
    return {
      middle: start.clone().add(end).multiplyScalar(0.5),
      rotation: new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        delta.clone().normalize(),
      ),
      length: delta.length(),
    };
  }, [from, to]);
  return (
    <mesh position={middle} quaternion={rotation} material={material} castShadow receiveShadow>
      <cylinderGeometry args={[radiusTop, radiusBottom, length, 12, 1]} />
    </mesh>
  );
}

/** An original procedural Scandinavian chair: all surfaces are actual 3D geometry. */
export default function ChairGeometry({
  material,
  lowDetail = false,
}: {
  material: THREE.Material;
  lowDetail?: boolean;
}) {
  const seat = useMemo(() => sculptedSeat(lowDetail), [lowDetail]),
    back = useMemo(() => curvedBack(lowDetail), [lowDetail]);
  useEffect(
    () => () => {
      seat.dispose();
      back.dispose();
    },
    [seat, back],
  );
  return (
    <group>
      <mesh
        geometry={seat}
        material={material}
        position={[0, 1.56, 0.06]}
        castShadow
        receiveShadow
      />
      <mesh
        geometry={back}
        material={material}
        position={[0, 2.86, -0.73]}
        rotation={[-0.12, 0, 0]}
        castShadow
        receiveShadow
      />
      {/* Tapered legs, continuous rear uprights, and pegged cross rails. */}
      <Beam
        from={[-0.79, 0.055, 0.75]}
        to={[-0.62, 1.58, 0.55]}
        radiusTop={0.085}
        radiusBottom={0.044}
        material={material}
      />
      <Beam
        from={[0.79, 0.055, 0.75]}
        to={[0.62, 1.58, 0.55]}
        radiusTop={0.085}
        radiusBottom={0.044}
        material={material}
      />
      <Beam
        from={[-0.8, 0.055, -0.76]}
        to={[-0.64, 1.6, -0.5]}
        radiusTop={0.08}
        radiusBottom={0.045}
        material={material}
      />
      <Beam
        from={[0.8, 0.055, -0.76]}
        to={[0.64, 1.6, -0.5]}
        radiusTop={0.08}
        radiusBottom={0.045}
        material={material}
      />
      <Beam
        from={[-0.64, 1.48, -0.5]}
        to={[-0.67, 2.91, -0.55]}
        radiusTop={0.055}
        radiusBottom={0.075}
        material={material}
      />
      <Beam
        from={[0.64, 1.48, -0.5]}
        to={[0.67, 2.91, -0.55]}
        radiusTop={0.055}
        radiusBottom={0.075}
        material={material}
      />
      <Beam
        from={[-0.61, 1.41, 0.54]}
        to={[0.61, 1.41, 0.54]}
        radiusTop={0.065}
        radiusBottom={0.065}
        material={material}
      />
      <Beam
        from={[-0.61, 1.41, -0.5]}
        to={[0.61, 1.41, -0.5]}
        radiusTop={0.065}
        radiusBottom={0.065}
        material={material}
      />
      <Beam
        from={[-0.65, 1.41, -0.5]}
        to={[-0.65, 1.41, 0.54]}
        radiusTop={0.065}
        radiusBottom={0.065}
        material={material}
      />
      <Beam
        from={[0.65, 1.41, -0.5]}
        to={[0.65, 1.41, 0.54]}
        radiusTop={0.065}
        radiusBottom={0.065}
        material={material}
      />
      <Beam
        from={[-0.72, 0.6, -0.62]}
        to={[-0.72, 0.6, 0.64]}
        radiusTop={0.032}
        radiusBottom={0.032}
        material={material}
      />
      <Beam
        from={[0.72, 0.6, -0.62]}
        to={[0.72, 0.6, 0.64]}
        radiusTop={0.032}
        radiusBottom={0.032}
        material={material}
      />
      <Beam
        from={[-0.72, 0.61, -0.06]}
        to={[0.72, 0.61, -0.06]}
        radiusTop={0.032}
        radiusBottom={0.032}
        material={material}
      />
      {/* Two rounded lumbar slats make the construction legible from every angle. */}
      <Beam
        from={[-0.24, 1.63, -0.49]}
        to={[-0.25, 2.72, -0.66]}
        radiusTop={0.035}
        radiusBottom={0.045}
        material={material}
      />
      <Beam
        from={[0.24, 1.63, -0.49]}
        to={[0.25, 2.72, -0.66]}
        radiusTop={0.035}
        radiusBottom={0.045}
        material={material}
      />
    </group>
  );
}
