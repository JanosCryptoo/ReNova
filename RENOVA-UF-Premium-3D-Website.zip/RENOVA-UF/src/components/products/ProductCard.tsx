import { Link } from 'react-router-dom';
import { Plus, Armchair } from 'lucide-react';
import type { Product } from '../../types';
import { formatPrice, safeImageUrl } from '../../lib/format';
import { useCart } from '../CartProvider';
export default function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const image = safeImageUrl(product.product_images[0]?.image_url);
  const available = product.stock > 0 && product.availability === 'available';
  return (
    <article className="product-card">
      <Link to={`/mobler/${product.id}`} className="product-image">
        {image ? (
          <img src={image} alt={product.name} loading="lazy" />
        ) : (
          <div className="product-no-image">
            <Armchair size={62} strokeWidth={0.8} />
            <span>Fotografi kommer</span>
          </div>
        )}
        <span className="product-tag">
          {available
            ? 'Ett unikt exemplar'
            : product.availability === 'reserved'
              ? 'Reserverad'
              : 'Såld'}
        </span>
      </Link>
      <div className="product-info">
        <div>
          <span className="eyebrow">{product.category}</span>
          <Link to={`/mobler/${product.id}`}>
            <h3>{product.name}</h3>
          </Link>
          <span>{formatPrice(product.price)}</span>
        </div>
        <button
          className="product-add icon-button"
          aria-label={`Lägg ${product.name} i varukorgen`}
          disabled={!available}
          onClick={() => add(product)}
        >
          <Plus size={22} />
        </button>
      </div>
    </article>
  );
}
