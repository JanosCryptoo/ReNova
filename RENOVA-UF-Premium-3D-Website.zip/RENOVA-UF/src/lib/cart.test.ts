import { describe, expect, it } from 'vitest';
import { parseCart } from './cart';
import { restoreAttempt } from './checkoutAttempt';
const id = '11111111-1111-4111-8111-111111111111';
describe('browser-local shopping state', () => {
  it('discards broken or malicious storage', () => {
    expect(parseCart('oops')).toEqual([]);
    expect(parseCart('{"items":[]}')).toEqual([]);
    expect(
      parseCart(
        JSON.stringify([
          { productId: id, quantity: -1 },
          { productId: 'javascript:alert(1)', quantity: 1 },
        ]),
      ),
    ).toEqual([]);
  });
  it('keeps a single valid line for one unique item', () => {
    expect(
      parseCart(
        JSON.stringify([
          { productId: id, quantity: 1 },
          { productId: id, quantity: 1 },
        ]),
      ),
    ).toEqual([{ productId: id, quantity: 1 }]);
  });
  it('restores a matching checkout attempt without generating another reservation', () => {
    const items = [{ productId: id, quantity: 1 }],
      customer = { name: 'Test Person', email: 'test@example.com' };
    const attempt = {
      id,
      createdAt: 1000,
      items,
      customer,
      signature: JSON.stringify({ items, customer }),
    };
    expect(restoreAttempt(JSON.stringify(attempt), 2000)?.id).toBe(id);
    expect(restoreAttempt(JSON.stringify({ ...attempt, signature: 'changed' }), 2000)).toBeNull();
    expect(restoreAttempt(JSON.stringify(attempt), 1000 + 46 * 60 * 1000)).toBeNull();
  });
});
