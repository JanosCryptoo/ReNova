import type { CartItem, ContactInput } from '../types';

export type Capabilities = {
  checkoutEnabled: boolean;
  contactEnabled: boolean;
  turnstileSiteKey?: string | null;
};

async function api<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(`/api/${path}`, {
    method: body === undefined ? 'GET' : 'POST',
    credentials: 'same-origin',
    headers: {
      Accept: 'application/json',
      ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!response.headers.get('content-type')?.includes('application/json')) {
    throw new Error('Tjänsten är inte aktiverad ännu. Kontakta oss gärna på Instagram.');
  }
  const result = await response.json();
  if (!response.ok)
    throw new Error(
      typeof result.error === 'string' ? result.error : 'Något gick fel. Försök igen.',
    );
  return result as T;
}

export async function getCapabilities(): Promise<Capabilities> {
  try {
    return await api<Capabilities>('config');
  } catch {
    return { checkoutEnabled: false, contactEnabled: false };
  }
}

export function sendContact(input: ContactInput) {
  return api<{ ok: boolean; message: string }>('contact', input);
}

export function createCheckout(
  items: CartItem[],
  customer: { name: string; email: string },
  requestId: string,
  turnstileToken?: string,
) {
  return api<{ url: string; orderId: string; statusToken: string }>('checkout', {
    items,
    customer,
    requestId,
    turnstileToken,
  });
}

export function getOrderStatus(orderId: string, token: string) {
  const query = new URLSearchParams({ orderId, token });
  return api<{ status: string; total: number; currency: string }>(`order-status?${query}`);
}

export function cancelCheckout(orderId: string, token: string) {
  return api<{ ok: boolean; status: string }>('cancel', { orderId, statusToken: token });
}
