import { requireSupabase } from './supabase';

export type UploadKind = 'image' | 'model';
export type ValidatedFile = { extension: string; mime: string };
const IMAGE_LIMIT = 8 * 1024 * 1024;
const MODEL_LIMIT = 20 * 1024 * 1024;

/** Validate actual content instead of trusting file.name or the browser's MIME hint. */
export async function validateUpload(file: File, kind: UploadKind): Promise<ValidatedFile> {
  const limit = kind === 'image' ? IMAGE_LIMIT : MODEL_LIMIT;
  if (!file.size || file.size > limit)
    throw new Error(`Filen måste vara mellan 1 byte och ${limit / 1024 / 1024} MB.`);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const ascii = (start: number, end: number) =>
    new TextDecoder().decode(bytes.subarray(start, end));
  if (kind === 'model') {
    if (bytes.length < 20 || ascii(0, 4) !== 'glTF')
      throw new Error('Välj en giltig GLB-modell med inbäddade texturer.');
    const view = new DataView(bytes.buffer);
    if (
      view.getUint32(4, true) !== 2 ||
      view.getUint32(8, true) !== bytes.length ||
      view.getUint32(16, true) !== 0x4e4f534a
    )
      throw new Error('Modellen måste vara en komplett GLB-fil i version 2.');
    const jsonLength = view.getUint32(12, true);
    if (jsonLength > bytes.length - 20 || jsonLength % 4 !== 0)
      throw new Error('GLB-filen är skadad.');
    let document: unknown;
    try {
      document = JSON.parse(
        ascii(20, 20 + jsonLength)
          .replace(/\0+$/, '')
          .trim(),
      );
    } catch {
      throw new Error('GLB-filen saknar giltig modelldata.');
    }
    function inspect(value: unknown) {
      if (!value || typeof value !== 'object') return;
      for (const [key, item] of Object.entries(value)) {
        const codecs = [
          'KHR_draco_mesh_compression',
          'EXT_meshopt_compression',
          'KHR_texture_basisu',
        ];
        if (codecs.includes(key) || (typeof item === 'string' && codecs.includes(item)))
          throw new Error(
            'Exportera GLB utan Draco, Meshopt eller KTX2. Använd inbäddade JPEG-/PNG-texturer.',
          );
        if (key === 'uri' && typeof item === 'string')
          throw new Error('Modellen måste innehålla alla resurser. Externa URI:er stöds inte.');
        inspect(item);
      }
    }
    inspect(document);
    return { extension: 'glb', mime: 'model/gltf-binary' };
  }
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff)
    return { extension: 'jpg', mime: 'image/jpeg' };
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((byte, i) => bytes[i] === byte))
    return { extension: 'png', mime: 'image/png' };
  if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP')
    return { extension: 'webp', mime: 'image/webp' };
  throw new Error('Välj en JPEG-, PNG- eller WebP-bild. SVG och andra filformat stöds inte.');
}

export async function uploadAsset(file: File, kind: UploadKind): Promise<string> {
  const client = requireSupabase();
  await validateUpload(file, kind);
  if (kind === 'image') {
    let bitmap: ImageBitmap;
    try {
      bitmap = await createImageBitmap(file);
    } catch {
      throw new Error('Bilden kunde inte läsas. Välj en annan bild.');
    }
    const tooLarge =
      bitmap.width > 8000 || bitmap.height > 8000 || bitmap.width * bitmap.height > 32_000_000;
    bitmap.close();
    if (tooLarge)
      throw new Error('Bilden är för stor. Använd högst 8 000 pixlar per sida och 32 megapixlar.');
  }
  const {
    data: { session },
  } = await client.auth.getSession();
  if (!session) throw new Error('Logga in igen innan du laddar upp en fil.');
  const body = new FormData();
  body.set('file', file);
  body.set('kind', kind);
  // The Pages Function verifies the user, current admin role and file contents again.
  // Direct Storage INSERT is denied by policy, so browser checks cannot be bypassed.
  const response = await fetch('/api/admin/upload', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { Authorization: `Bearer ${session.access_token}` },
    body,
  });
  if (!response.headers.get('content-type')?.includes('application/json'))
    throw new Error('Uppladdningstjänsten är inte aktiverad. Kontrollera serverinställningarna.');
  const result = await response.json();
  if (!response.ok || typeof result.url !== 'string')
    throw new Error(
      typeof result.error === 'string' ? result.error : 'Filen kunde inte laddas upp. Försök igen.',
    );
  return result.url;
}
