import type { Order, Product, ProductImage, Restoration } from '../types';
import type { CompanyImage } from './catalog';
import { requireSupabase } from './supabase';

export type ProductDraft = Omit<Product, 'created_at' | 'product_images'>;
export type ContactMessage = {
  id: string;
  name: string;
  email: string;
  message: string;
  created_at: string;
  product_id: string | null;
};

export async function isCurrentUserAdmin(): Promise<boolean> {
  const client = requireSupabase();
  const {
    data: { user },
    error,
  } = await client.auth.getUser();
  if (error || !user) return false;
  const result = await client
    .from('admin_roles')
    .select('role')
    .eq('user_id', user.id)
    .maybeSingle();
  return !result.error && result.data?.role === 'admin';
}

export async function getAdminProducts(): Promise<Product[]> {
  const { data, error } = await requireSupabase()
    .from('products')
    .select('*, product_images(*)')
    .order('created_at', { ascending: false });
  if (error)
    throw new Error('Möblerna kunde inte hämtas. Kontrollera anslutningen och din behörighet.');
  return data as Product[];
}

export async function saveProduct(draft: ProductDraft, existing: boolean): Promise<void> {
  if (
    !draft.name.trim() ||
    !draft.category.trim() ||
    draft.price < 100 ||
    !Number.isSafeInteger(draft.price) ||
    draft.stock < 0 ||
    !Number.isSafeInteger(draft.stock)
  )
    throw new Error('Fyll i namn, kategori, giltigt pris och lagersaldo.');
  const client = requireSupabase();
  const query = existing
    ? client.from('products').update(draft).eq('id', draft.id)
    : client.from('products').insert(draft);
  const { error } = await query.select('id').single();
  if (error)
    throw new Error(
      'Möbeln kunde inte sparas. En pågående reservation kan låsa pris och lagersaldo. Försök igen eller kontrollera behörigheten.',
    );
}

export async function deleteProduct(id: string): Promise<void> {
  const { error } = await requireSupabase()
    .from('products')
    .delete()
    .eq('id', id)
    .select('id')
    .single();
  if (error)
    throw new Error(
      'Möbeln kunde inte tas bort. Möbler med beställningar eller reservationer måste avpubliceras i stället.',
    );
}

export async function addProductImage(
  productId: string,
  url: string,
  sortOrder: number,
): Promise<void> {
  const { error } = await requireSupabase()
    .from('product_images')
    .insert({ product_id: productId, image_url: url, sort_order: sortOrder });
  if (error)
    throw new Error(
      'Filen laddades upp, men kopplingen till möbeln kunde inte sparas. Försök igen.',
    );
}

export async function removeProductImage(image: ProductImage): Promise<void> {
  if (!image.id) return;
  const { error } = await requireSupabase()
    .from('product_images')
    .delete()
    .eq('id', image.id)
    .select('id')
    .single();
  if (error) throw new Error('Bilden kunde inte tas bort från möbeln.');
}

export async function getAdminRestorations(): Promise<Restoration[]> {
  const { data, error } = await requireSupabase().from('restorations').select('*').order('id');
  if (error) throw new Error('Förvandlingarna kunde inte hämtas.');
  return data as Restoration[];
}

export async function saveRestoration(restoration: Restoration, existing: boolean): Promise<void> {
  if (!restoration.title.trim() || !restoration.before_image_url || !restoration.after_image_url)
    throw new Error('Ange en titel och både före- och efterbild.');
  const client = requireSupabase();
  const query = existing
    ? client.from('restorations').update(restoration).eq('id', restoration.id)
    : client.from('restorations').insert(restoration);
  const { error } = await query.select('id').single();
  if (error) throw new Error('Förvandlingen kunde inte sparas.');
}

export async function deleteRestoration(id: string): Promise<void> {
  const { error } = await requireSupabase()
    .from('restorations')
    .delete()
    .eq('id', id)
    .select('id')
    .single();
  if (error) throw new Error('Förvandlingen kunde inte tas bort.');
}

export async function getAdminOrders(): Promise<Order[]> {
  const { data, error } = await requireSupabase()
    .from('orders')
    .select(
      'id,total,status,customer_name,customer_email,created_at,payment_reference,order_items(name,product_id,quantity,price)',
    )
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error('Beställningarna kunde inte hämtas.');
  return data as Order[];
}

export async function reconcileOrder(orderId: string): Promise<void> {
  const {
    data: { session },
  } = await requireSupabase().auth.getSession();
  if (!session) throw new Error('Logga in igen för att kontrollera reservationen.');
  const response = await fetch('/api/admin/reconcile', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ orderId }),
    credentials: 'same-origin',
  });
  if (!response.headers.get('content-type')?.includes('application/json'))
    throw new Error('Betalningstjänsten är inte ansluten.');
  const result = await response.json();
  if (!response.ok)
    throw new Error(
      typeof result.error === 'string' ? result.error : 'Reservationen kunde inte kontrolleras.',
    );
}

export async function getContactMessages(): Promise<ContactMessage[]> {
  const { data, error } = await requireSupabase()
    .from('contact_messages')
    .select('id,name,email,message,created_at,product_id')
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw new Error('Meddelandena kunde inte hämtas.');
  return data as ContactMessage[];
}

export async function getAdminCompanyImages(): Promise<CompanyImage[]> {
  const { data, error } = await requireSupabase()
    .from('company_images')
    .select('*')
    .order('sort_order');
  if (error) throw new Error('Företagsbilderna kunde inte hämtas.');
  return data as CompanyImage[];
}

export async function saveCompanyImage(image: CompanyImage): Promise<void> {
  const { error } = await requireSupabase()
    .from('company_images')
    .upsert(image)
    .select('id')
    .single();
  if (error) throw new Error('Företagsbilden kunde inte sparas.');
}

export async function deleteCompanyImage(id: string): Promise<void> {
  const { error } = await requireSupabase()
    .from('company_images')
    .delete()
    .eq('id', id)
    .select('id')
    .single();
  if (error) throw new Error('Företagsbilden kunde inte tas bort.');
}
