import { describe, expect, it, vi } from 'vitest';

vi.mock('./supabase', () => ({ requireSupabase: vi.fn() }));
import { validateUpload } from './uploads';

function glb(document: object) {
  const json = new TextEncoder().encode(JSON.stringify(document));
  const padded = Math.ceil(json.length / 4) * 4;
  const bytes = new Uint8Array(20 + padded);
  const view = new DataView(bytes.buffer);
  bytes.set(new TextEncoder().encode('glTF'));
  view.setUint32(4, 2, true);
  view.setUint32(8, bytes.length, true);
  view.setUint32(12, padded, true);
  view.setUint32(16, 0x4e4f534a, true);
  bytes.fill(32, 20);
  bytes.set(json, 20);
  return new File([bytes], 'chair.glb', { type: 'model/gltf-binary' });
}

describe('admin upload validation', () => {
  it('rejects SVG disguised as a JPEG', async () => {
    await expect(
      validateUpload(
        new File(['<svg><script>alert(1)</script></svg>'], 'photo.jpg', { type: 'image/jpeg' }),
        'image',
      ),
    ).rejects.toThrow('JPEG');
  });
  it('accepts actual PNG headers independent of an untrusted file extension', async () => {
    const file = new File([new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10, 0])], 'renamed.txt');
    await expect(validateUpload(file, 'image')).resolves.toEqual({
      extension: 'png',
      mime: 'image/png',
    });
  });
  it('rejects empty and oversized files', async () => {
    await expect(validateUpload(new File([], 'empty.jpg'), 'image')).rejects.toThrow('1 byte');
    await expect(
      validateUpload(new File([new Uint8Array(8 * 1024 * 1024 + 1)], 'large.jpg'), 'image'),
    ).rejects.toThrow('8 MB');
  });
  it('rejects models with external image resources', async () => {
    await expect(
      validateUpload(
        glb({ asset: { version: '2.0' }, images: [{ uri: 'https://example.com/tracker.jpg' }] }),
        'model',
      ),
    ).rejects.toThrow('Externa URI');
  });
  it('accepts self-contained GLB documents', async () => {
    await expect(
      validateUpload(glb({ asset: { version: '2.0' }, buffers: [{ byteLength: 0 }] }), 'model'),
    ).resolves.toEqual({ extension: 'glb', mime: 'model/gltf-binary' });
  });
  it('rejects compressed models that would require an external runtime decoder', async () => {
    await expect(
      validateUpload(
        glb({ asset: { version: '2.0' }, extensionsRequired: ['KHR_draco_mesh_compression'] }),
        'model',
      ),
    ).rejects.toThrow('utan Draco');
  });
  it('rejects a truncated model', async () => {
    const file = glb({ asset: { version: '2.0' } });
    const truncated = new File([await file.slice(0, file.size - 4).arrayBuffer()], 'broken.glb');
    await expect(validateUpload(truncated, 'model')).rejects.toThrow('komplett GLB');
  });
});
