import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL?.trim();
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim();

function validConfiguration() {
  if (!url || !key || key.startsWith('sb_secret_')) return false;
  try {
    return new URL(url).protocol === 'https:';
  } catch {
    return false;
  }
}

export const isSupabaseConfigured = validConfiguration();
// This client only receives the public publishable key. All authorization lives in RLS.
export const supabase = isSupabaseConfigured
  ? createClient(url!, key!, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    })
  : null;

export function requireSupabase() {
  if (!supabase) throw new Error('Databasen är inte ansluten ännu.');
  return supabase;
}
