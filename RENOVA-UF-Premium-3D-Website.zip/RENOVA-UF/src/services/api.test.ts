import { afterEach, describe, expect, it, vi } from 'vitest';
import { cancelCheckout, createCheckout, getCapabilities, sendContact } from './api';

afterEach(() => vi.unstubAllGlobals());

describe('optional service boundaries', () => {
  it('keeps checkout disabled when a static host returns HTML for an API route', async () => {
    vi.stubGlobal(
      'fetch',
      vi
        .fn()
        .mockResolvedValue(
          new Response('<html>SPA</html>', { headers: { 'Content-Type': 'text/html' } }),
        ),
    );
    await expect(getCapabilities()).resolves.toEqual({
      checkoutEnabled: false,
      contactEnabled: false,
    });
  });
  it('keeps checkout disabled on a network failure', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('offline')));
    await expect(getCapabilities()).resolves.toEqual({
      checkoutEnabled: false,
      contactEnabled: false,
    });
  });
  it('reports contact failure rather than claiming the message was stored', async () => {
    vi.stubGlobal(
      'fetch',
      vi
        .fn()
        .mockResolvedValue(
          Response.json({ error: 'Meddelandet kunde inte sparas.' }, { status: 503 }),
        ),
    );
    await expect(
      sendContact({
        name: 'Test person',
        email: 'test@example.com',
        message: 'Det här är ett testmeddelande.',
        website: '',
      }),
    ).rejects.toThrow('kunde inte sparas');
  });
  it('sends product identity and quantity, with no client price or total', async () => {
    const fetch = vi
      .fn()
      .mockResolvedValue(
        Response.json({
          url: 'https://checkout.stripe.com/test',
          orderId: 'order',
          statusToken: 'token',
        }),
      );
    vi.stubGlobal('fetch', fetch);
    await createCheckout(
      [{ productId: 'product', quantity: 1 }],
      { name: 'Test person', email: 'test@example.com' },
      'request-id',
      'human-token',
    );
    const request = JSON.parse(fetch.mock.calls[0][1].body);
    expect(request).toEqual({
      items: [{ productId: 'product', quantity: 1 }],
      customer: { name: 'Test person', email: 'test@example.com' },
      requestId: 'request-id',
      turnstileToken: 'human-token',
    });
  });
  it('includes the opaque authorization token when asking to cancel a reservation', async () => {
    const fetch = vi.fn().mockResolvedValue(Response.json({ ok: true, status: 'expired' }));
    vi.stubGlobal('fetch', fetch);
    await cancelCheckout('order', 'opaque-token');
    expect(JSON.parse(fetch.mock.calls[0][1].body)).toEqual({
      orderId: 'order',
      statusToken: 'opaque-token',
    });
  });
});
