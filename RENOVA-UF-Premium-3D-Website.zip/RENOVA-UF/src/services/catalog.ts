import type { Product, Restoration } from '../types';
import { supabase } from './supabase';

export type CompanyImage = {
  id: string;
  image_url: string;
  alt: string;
  sort_order: number;
  published: boolean;
};

export async function getProducts(): Promise<Product[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('products')
    .select('*, product_images(*)')
    .eq('published', true)
    .order('created_at', { ascending: false });
  if (error) throw new Error('Möblerna kunde inte hämtas. Försök igen om en stund.');
  return (data as Product[]).map(sortImages);
}

export async function getProduct(id: string): Promise<Product | null> {
  if (!supabase) return null;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const { data, error } = await supabase
    .from('products')
    .select('*, product_images(*)')
    .eq('id', id)
    .eq('published', true)
    .maybeSingle();
  if (error) throw new Error('Möbeln kunde inte hämtas. Försök igen om en stund.');
  return data ? sortImages(data as Product) : null;
}

export async function getRestorations(): Promise<Restoration[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('restorations')
    .select('*')
    .eq('published', true)
    .order('id');
  if (error) throw new Error('Förvandlingarna kunde inte hämtas. Försök igen om en stund.');
  return data as Restoration[];
}

export async function getCompanyImages(): Promise<CompanyImage[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('company_images')
    .select('*')
    .eq('published', true)
    .order('sort_order');
  if (error) throw new Error('Bilderna kunde inte hämtas just nu.');
  return data as CompanyImage[];
}

function sortImages(product: Product): Product {
  return {
    ...product,
    product_images: [...(product.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order),
  };
}
