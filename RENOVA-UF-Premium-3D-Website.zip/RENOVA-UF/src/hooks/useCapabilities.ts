import { useEffect, useState } from 'react';
import { getCapabilities, type Capabilities } from '../services/api';
export function useCapabilities() {
  const [config, setConfig] = useState<Capabilities>({
    checkoutEnabled: false,
    contactEnabled: false,
  });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let active = true;
    getCapabilities()
      .then((r) => {
        if (active) setConfig(r);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);
  return { ...config, loading };
}
