import { useEffect, useState } from 'react';
import type { Product, Restoration } from '../types';
import { getProducts, getRestorations } from '../services/catalog';
export function useCatalog() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [version, setVersion] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError('');
    getProducts()
      .then((p) => {
        if (active) setProducts(p);
      })
      .catch(() => {
        if (active) setError('Vi kunde inte hämta möblerna. Försök igen om en stund.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [version]);
  return { products, loading, error, reload: () => setVersion((v) => v + 1) };
}
export function useRestorations() {
  const [items, setItems] = useState<Restoration[]>([]);
  const [error, setError] = useState(false);
  useEffect(() => {
    let active = true;
    getRestorations()
      .then((r) => {
        if (active) setItems(r);
      })
      .catch(() => {
        if (active) setError(true);
      });
    return () => {
      active = false;
    };
  }, []);
  return { items, error };
}
