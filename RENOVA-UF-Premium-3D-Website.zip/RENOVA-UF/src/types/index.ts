export type ProductImage = {
  id?: string;
  product_id?: string;
  image_url: string;
  sort_order: number;
};
export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  condition: string;
  dimensions: string;
  stock: number;
  availability: 'available' | 'reserved' | 'sold';
  published: boolean;
  featured: boolean;
  model_url: string | null;
  created_at: string;
  product_images: ProductImage[];
};
export type Restoration = {
  id: string;
  product_id: string | null;
  title: string;
  description: string;
  before_image_url: string;
  after_image_url: string;
  published: boolean;
};
export type ContactInput = {
  name: string;
  email: string;
  message: string;
  product_id?: string;
  website: string;
  turnstileToken?: string;
};
export type CartItem = { productId: string; quantity: number };
export type Order = {
  id: string;
  total: number;
  status: string;
  customer_name: string;
  customer_email: string;
  created_at: string;
  payment_reference: string | null;
  order_items?: { name: string; product_id: string; quantity: number; price: number }[];
};
