import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users } from 'lucide-react';
import { Reveal } from '../components/animations/Reveal';
import { getCompanyImages } from '../services/catalog';
import { safeImageUrl } from '../lib/format';
export default function About() {
  const [images, setImages] = useState<{ id: string; image_url: string; alt: string }[]>([]);
  useEffect(() => {
    let active = true;
    getCompanyImages()
      .then((r) => {
        if (active) setImages(r);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);
  return (
    <>
      <div className="container">
        <Reveal className="page-intro">
          <span className="eyebrow">Om RENOVA UF</span>
          <h1>
            Nya idéer.
            <br />
            <em>Gamla favoriter.</em>
          </h1>
          <p>
            Vi är RENOVA UF från JENSEN Gymnasium Eskilstuna. Med nyfikenhet, omtanke och en tro på
            återbruk ger vi möbler en andra chans.
          </p>
        </Reveal>
        <section className="about-statement">
          <Reveal>
            <span className="eyebrow">Vår övertygelse</span>
            <h2>
              Det bästa med en möbel
              <br />
              kan vara det som
              <br />
              <em>redan finns.</em>
            </h2>
          </Reveal>
          <Reveal>
            <p>
              En fin form. Ett levande material. Känslan av något som har en historia. Vi vill
              hjälpa fler att upptäcka värdet i begagnade möbler.
            </p>
            <p>
              Vi köper in slitna möbler, rengör, reparerar och fräschar upp dem. Sedan säljer vi dem
              vidare till ett överkomligt pris. På så sätt får de fortsätta användas, istället för
              att slängas.
            </p>
            <Link to="/process" className="text-link">
              Läs om vår process
            </Link>
          </Reveal>
        </section>
      </div>
      <section className="about-quote">
        <Reveal>
          <blockquote>
            “Från gammalt
            <br />
            <em>till nytt.</em>”
          </blockquote>
          <span className="eyebrow">En enkel tanke. Vår drivkraft.</span>
        </Reveal>
      </section>
      <section className="container section team-section">
        <Reveal>
          <span className="eyebrow">Människorna bakom</span>
          <h2>
            Omtanke börjar
            <br />
            <em>med oss.</em>
          </h2>
          <p>
            RENOVA UF är ett UF-företag vid JENSEN Gymnasium Eskilstuna. Här växer vårt företag
            fram, en möbel i taget.
          </p>
          <Link to="/kontakt" className="button button-outline">
            Säg hej till oss
          </Link>
        </Reveal>
        <Reveal>
          {images.length ? (
            <div className="team-gallery">
              {images.map((img) => (
                <img key={img.id} src={safeImageUrl(img.image_url)} alt={img.alt} loading="lazy" />
              ))}
            </div>
          ) : (
            <div className="team-empty">
              <Users size={56} strokeWidth={0.7} />
              <span className="eyebrow">Team RENOVA UF</span>
              <p>
                Här kommer du snart att få
                <br />
                möta oss bakom möblerna.
              </p>
            </div>
          )}
        </Reveal>
      </section>
    </>
  );
}
