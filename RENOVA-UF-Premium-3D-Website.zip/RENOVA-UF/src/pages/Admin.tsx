import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Check, ImagePlus, LockKeyhole, LogOut, Plus, ShieldCheck, X } from 'lucide-react';
import type { Order, Product, Restoration } from '../types';
import type { CompanyImage } from '../services/catalog';
import { isSupabaseConfigured, requireSupabase, supabase } from '../services/supabase';
import { uploadAsset } from '../services/uploads';
import {
  addProductImage,
  deleteCompanyImage,
  deleteProduct,
  deleteRestoration,
  getAdminCompanyImages,
  getAdminOrders,
  getAdminProducts,
  getAdminRestorations,
  getContactMessages,
  isCurrentUserAdmin,
  reconcileOrder,
  removeProductImage,
  saveCompanyImage,
  saveProduct,
  saveRestoration,
  type ContactMessage,
  type ProductDraft,
} from '../services/admin';
import '../styles/admin.css';

type Tab = 'products' | 'restorations' | 'orders' | 'messages' | 'company';
const tabs: { id: Tab; label: string }[] = [
  { id: 'products', label: 'Möbler' },
  { id: 'restorations', label: 'Före & efter' },
  { id: 'orders', label: 'Beställningar' },
  { id: 'messages', label: 'Meddelanden' },
  { id: 'company', label: 'Företagsbilder' },
];
const money = (price: number) =>
  new Intl.NumberFormat('sv-SE', {
    style: 'currency',
    currency: 'SEK',
    maximumFractionDigits: 2,
  }).format(price / 100);
const date = (value: string) =>
  new Intl.DateTimeFormat('sv-SE', { dateStyle: 'medium', timeStyle: 'short' }).format(
    new Date(value),
  );
const status: Record<string, string> = {
  creating: 'Betalning förbereds',
  pending: 'Väntar på betalning',
  payment_pending: 'Betalning behandlas',
  reserved: 'Reserverad',
  paid: 'Betald',
  processing: 'Betalning behandlas',
  expired: 'Utgången',
  cancelled: 'Avbruten',
  failed: 'Misslyckad',
  refunded: 'Återbetald',
  available: 'Tillgänglig',
  sold: 'Såld',
};

function emptyProduct(): ProductDraft {
  return {
    id: crypto.randomUUID(),
    name: '',
    description: '',
    price: 0,
    category: 'Stolar',
    condition: '',
    dimensions: '',
    stock: 1,
    availability: 'available',
    published: false,
    featured: false,
    model_url: null,
  };
}
function productDraft(product: Product): ProductDraft {
  const { created_at: _created, product_images: _images, ...draft } = product;
  return draft;
}
function emptyRestoration(): Restoration {
  return {
    id: crypto.randomUUID(),
    product_id: null,
    title: '',
    description: '',
    before_image_url: '',
    after_image_url: '',
    published: false,
  };
}

export default function Admin() {
  const [auth, setAuth] = useState<'loading' | 'login' | 'denied' | 'admin'>(
    isSupabaseConfigured ? 'loading' : 'login',
  );
  const [tab, setTab] = useState<Tab>('products');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [restorations, setRestorations] = useState<Restoration[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [companyImages, setCompanyImages] = useState<CompanyImage[]>([]);
  const [draft, setDraft] = useState<ProductDraft | null>(null);
  const [restorationDraft, setRestorationDraft] = useState<Restoration | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{
    id: string;
    kind: 'product' | 'restoration' | 'company';
  } | null>(null);

  const refresh = useCallback(async () => {
    const [nextProducts, nextRestorations, nextOrders, nextMessages, nextImages] =
      await Promise.all([
        getAdminProducts(),
        getAdminRestorations(),
        getAdminOrders(),
        getContactMessages(),
        getAdminCompanyImages(),
      ]);
    setProducts(nextProducts);
    setRestorations(nextRestorations);
    setOrders(nextOrders);
    setMessages(nextMessages);
    setCompanyImages(nextImages);
  }, []);

  useEffect(() => {
    if (!supabase) return;
    let active = true;
    let generation = 0;
    const client = supabase;
    const check = async () => {
      const current = ++generation;
      try {
        const {
          data: { user },
        } = await client.auth.getUser();
        const allowed = user ? await isCurrentUserAdmin() : false;
        if (!active || current !== generation) return;
        setAuth(!user ? 'login' : allowed ? 'admin' : 'denied');
        if (allowed) await refresh();
        else {
          setProducts([]);
          setOrders([]);
          setMessages([]);
          setDraft(null);
          setRestorationDraft(null);
        }
      } catch {
        if (active && current === generation) {
          setError('Behörigheten kunde inte verifieras. Logga in igen.');
          setAuth('login');
        }
      }
    };
    void check();
    // Supabase auth callbacks must remain synchronous; auth/database calls run after it returns.
    const {
      data: { subscription },
    } = client.auth.onAuthStateChange(() => {
      setTimeout(() => {
        if (active) void check();
      }, 0);
    });
    return () => {
      active = false;
      generation++;
      subscription.unsubscribe();
    };
  }, [refresh]);

  async function run(action: () => Promise<void>, success = '') {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await action();
      if (success) setNotice(success);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Något gick fel. Försök igen.');
    } finally {
      setBusy(false);
    }
  }

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    await run(async () => {
      const { error: loginError } = await requireSupabase().auth.signInWithPassword({
        email: String(values.get('email')).trim(),
        password: String(values.get('password')),
      });
      if (loginError)
        throw new Error('Inloggningen misslyckades. Kontrollera dina uppgifter och försök igen.');
    });
  }

  async function logout() {
    await run(async () => {
      const { error: logoutError } = await requireSupabase().auth.signOut();
      if (logoutError) throw new Error('Du kunde inte loggas ut. Försök igen.');
      setAuth('login');
      setProducts([]);
      setOrders([]);
      setMessages([]);
      setRestorations([]);
      setCompanyImages([]);
      setDraft(null);
      setRestorationDraft(null);
    });
  }

  if (!isSupabaseConfigured)
    return (
      <div className="container admin-page">
        <div className="admin-setup">
          <span className="admin-lock">
            <LockKeyhole size={28} strokeWidth={1.3} />
          </span>
          <p className="eyebrow">RENOVA UF · Administration</p>
          <h1>
            En plats för
            <br />
            <em>nästa kapitel.</em>
          </h1>
          <p>
            Här kommer ni att hantera möbler, bilder och beställningar. Anslut er databas för att
            öppna den skyddade arbetsytan.
          </p>
          <ol className="admin-setup-steps">
            <li>Kör den medföljande databasmigreringen i Supabase.</li>
            <li>Skapa ett administratörskonto och ge det behörighet enligt installationsguiden.</li>
            <li>
              Lägg till Supabase-adressen och den publika nyckeln i Cloudflare Pages. Publicera
              sedan på nytt.
            </li>
          </ol>
          <p className="admin-caption">
            Inga inloggningsuppgifter eller kunduppgifter lagras i den här förhandsvisningen.
            Installationsguiden finns i projektets README.
          </p>
          <Link to="/" className="button button-outline">
            Till startsidan
          </Link>
        </div>
      </div>
    );

  if (auth === 'loading')
    return (
      <div className="container admin-page">
        <div className="admin-setup">
          <ShieldCheck size={30} />
          <h1>Kontrollerar behörighet.</h1>
          <p role="status">Ett ögonblick…</p>
        </div>
      </div>
    );

  if (auth !== 'admin')
    return (
      <div className="container admin-page">
        <div className="admin-login">
          <p className="eyebrow">RENOVA UF · Administration</p>
          <h1>{auth === 'denied' ? 'Behörighet saknas.' : 'Välkommen tillbaka.'}</h1>
          <p>
            {auth === 'denied'
              ? 'Ditt konto saknar administratörsbehörighet. Kontakta den som ansvarar för webbplatsen.'
              : 'Logga in med ditt administratörskonto för att fortsätta.'}
          </p>
          {error && (
            <p role="alert" className="admin-error">
              {error}
            </p>
          )}
          {auth === 'denied' ? (
            <button className="button" onClick={() => void logout()} disabled={busy}>
              Logga ut
            </button>
          ) : (
            <form onSubmit={login} className="admin-form">
              <label>
                E-post
                <input name="email" type="email" required autoComplete="username" maxLength={254} />
              </label>
              <label>
                Lösenord
                <input name="password" type="password" required autoComplete="current-password" />
              </label>
              <button className="button" disabled={busy}>
                {busy ? 'Loggar in…' : 'Logga in'}
              </button>
              <p className="admin-caption">
                Konton skapas av webbplatsens ansvariga. Kontakta dem om du behöver återställa ditt
                lösenord.
              </p>
            </form>
          )}
        </div>
      </div>
    );

  const existingProduct = products.find((product) => product.id === draft?.id);
  const existingRestoration = restorations.some((item) => item.id === restorationDraft?.id);

  return (
    <div className="container admin-page">
      <header className="admin-heading">
        <div>
          <p className="eyebrow">RENOVA UF · Din arbetsyta</p>
          <h1>Omsorg om varje detalj.</h1>
        </div>
        <button className="button button-outline" onClick={() => void logout()} disabled={busy}>
          <LogOut size={16} /> Logga ut
        </button>
      </header>
      <nav className="admin-tabs" aria-label="Administration">
        {tabs.map((item) => (
          <button
            key={item.id}
            aria-current={tab === item.id ? 'page' : undefined}
            onClick={() => {
              setTab(item.id);
              setError('');
              setNotice('');
            }}
          >
            {item.label}
          </button>
        ))}
      </nav>
      {error && (
        <p className="admin-error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="admin-success" role="status">
          <Check size={18} />
          {notice}
        </p>
      )}

      {tab === 'products' && (
        <section aria-label="Hantera möbler">
          <div className="admin-toolbar">
            <p>{products.length} möbler · utkast och publicerade</p>
            <button className="button" onClick={() => setDraft(emptyProduct())} disabled={busy}>
              <Plus size={17} />
              Lägg till möbel
            </button>
          </div>
          <div className="admin-product-list">
            {products.map((product) => (
              <article key={product.id}>
                <div className="admin-product-image">
                  {product.product_images?.[0] ? (
                    <img src={product.product_images[0].image_url} alt="" />
                  ) : (
                    <ImagePlus size={26} strokeWidth={1} />
                  )}
                </div>
                <div>
                  <h2>{product.name}</h2>
                  <p>
                    {money(product.price)} · {product.category}
                  </p>
                  <span className="admin-caption">
                    {product.published ? 'Publicerad' : 'Utkast'} ·{' '}
                    {status[product.availability] ?? product.availability}
                    {product.featured ? ' · Utvald' : ''}
                  </span>
                </div>
                <div className="admin-actions">
                  <button
                    className="admin-text-button"
                    onClick={() => setDraft(productDraft(product))}
                  >
                    Redigera
                  </button>
                  <button
                    className="admin-text-button"
                    onClick={() => setDeleteTarget({ kind: 'product', id: product.id })}
                  >
                    Ta bort
                  </button>
                </div>
              </article>
            ))}
          </div>
          {!products.length && (
            <Empty
              title="Den första möbeln väntar."
              text="Lägg till en möbel som utkast, ladda upp era fotografier och publicera när allt är klart."
            />
          )}
          {draft && (
            <section className="admin-editor" aria-label="Redigera möbel">
              <div className="admin-toolbar">
                <h2>{existingProduct ? 'Redigera möbel' : 'Ny möbel'}</h2>
                <button
                  className="admin-icon-button"
                  aria-label="Stäng redigering"
                  onClick={() => setDraft(null)}
                  disabled={busy}
                >
                  <X />
                </button>
              </div>
              <form
                className="admin-form admin-form-grid"
                onSubmit={(event) => {
                  event.preventDefault();
                  void run(async () => {
                    if (draft.published && !existingProduct?.product_images.length)
                      throw new Error(
                        'Spara först som utkast och lägg till minst ett äkta produktfoto innan du publicerar.',
                      );
                    await saveProduct(draft, !!existingProduct);
                    await refresh();
                  }, 'Möbeln är sparad.');
                }}
              >
                <label>
                  Möbelns namn
                  <input
                    required
                    maxLength={150}
                    value={draft.name}
                    onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                  />
                </label>
                <label>
                  Pris i SEK
                  <input
                    required
                    type="number"
                    min="1"
                    max="1000000"
                    step="0.01"
                    value={draft.price ? draft.price / 100 : ''}
                    onChange={(event) =>
                      setDraft({ ...draft, price: Math.round(Number(event.target.value) * 100) })
                    }
                  />
                </label>
                <label>
                  Kategori
                  <input
                    required
                    list="furniture-categories"
                    maxLength={80}
                    value={draft.category}
                    onChange={(event) => setDraft({ ...draft, category: event.target.value })}
                  />
                  <datalist id="furniture-categories">
                    {[
                      ...new Set([
                        'Stolar',
                        'Bord',
                        'Förvaring',
                        'Övrigt',
                        ...products.map((product) => product.category),
                      ]),
                    ].map((category) => (
                      <option key={category} value={category} />
                    ))}
                  </datalist>
                </label>
                <label>
                  Mått (bredd × djup × höjd, cm)
                  <input
                    required
                    maxLength={120}
                    value={draft.dimensions}
                    onChange={(event) => setDraft({ ...draft, dimensions: event.target.value })}
                  />
                </label>
                <label className="admin-full">
                  Beskrivning
                  <textarea
                    required
                    rows={5}
                    maxLength={6000}
                    value={draft.description}
                    onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                  />
                </label>
                <label className="admin-full">
                  Skick och restaurering
                  <textarea
                    required
                    rows={3}
                    maxLength={2000}
                    value={draft.condition}
                    onChange={(event) => setDraft({ ...draft, condition: event.target.value })}
                  />
                </label>
                <label>
                  Lagersaldo
                  <input
                    required
                    type="number"
                    min="0"
                    max="100"
                    step="1"
                    value={draft.stock}
                    disabled={draft.availability === 'reserved'}
                    onChange={(event) => {
                      const stock = Number(event.target.value);
                      setDraft({ ...draft, stock, availability: stock ? 'available' : 'sold' });
                    }}
                  />
                </label>
                <div className="admin-stock">
                  <span>{status[draft.availability]}</span>
                  <button
                    type="button"
                    className="admin-text-button"
                    disabled={draft.availability === 'reserved'}
                    onClick={() => setDraft({ ...draft, stock: 0, availability: 'sold' })}
                  >
                    Markera som såld
                  </button>
                </div>
                <label className="admin-checkbox">
                  <input
                    type="checkbox"
                    checked={draft.published}
                    onChange={(event) => setDraft({ ...draft, published: event.target.checked })}
                  />
                  Publicera i butiken
                </label>
                <label className="admin-checkbox">
                  <input
                    type="checkbox"
                    checked={draft.featured}
                    onChange={(event) => setDraft({ ...draft, featured: event.target.checked })}
                  />
                  Visa som utvald möbel
                </label>
                <p className="admin-caption admin-full">
                  Priser och lager låses medan en kund har en aktiv betalningsreservation. Ändra
                  inte lagret för en betald beställning utan att hantera beställningen först.
                </p>
                <div className="admin-full">
                  <button className="button" disabled={busy}>
                    {busy ? 'Sparar…' : 'Spara möbel'}
                  </button>
                </div>
              </form>
              <div className="admin-media-section">
                <h3>Produktfotografier</h3>
                <p>
                  Äkta bilder av den här möbeln. JPEG, PNG eller WebP, högst 8 MB per bild. Första
                  bilden blir omslag.
                </p>
                {!existingProduct ? (
                  <p className="admin-caption">
                    Spara möbeln som utkast innan du laddar upp bilder.
                  </p>
                ) : (
                  <>
                    <div className="admin-image-grid">
                      {[...existingProduct.product_images]
                        .sort((a, b) => a.sort_order - b.sort_order)
                        .map((image, index) => (
                          <figure key={image.id ?? image.image_url}>
                            <img
                              src={image.image_url}
                              alt={`${existingProduct.name}, bild ${index + 1}`}
                            />
                            <figcaption>
                              {index === 0 ? 'Omslagsbild' : `Bild ${index + 1}`}
                              <button
                                className="admin-text-button"
                                disabled={busy}
                                onClick={() =>
                                  void run(async () => {
                                    await removeProductImage(image);
                                    await refresh();
                                  }, 'Bilden har tagits bort från möbeln.')
                                }
                              >
                                Ta bort
                              </button>
                            </figcaption>
                          </figure>
                        ))}
                    </div>
                    <label className="admin-upload">
                      <ImagePlus size={20} />
                      Lägg till fotografier
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        multiple
                        disabled={busy}
                        onChange={(event) => {
                          const files = Array.from(event.target.files ?? []);
                          event.target.value = '';
                          if (!files.length) return;
                          void run(async () => {
                            if (files.length + existingProduct.product_images.length > 12)
                              throw new Error('Välj högst 12 bilder per möbel.');
                            let sort =
                              Math.max(
                                -1,
                                ...existingProduct.product_images.map((image) => image.sort_order),
                              ) + 1;
                            for (const file of files) {
                              const url = await uploadAsset(file, 'image');
                              await addProductImage(existingProduct.id, url, sort++);
                            }
                            await refresh();
                          }, 'Produktbilderna är sparade.');
                        }}
                      />
                    </label>
                  </>
                )}
              </div>
              <div className="admin-media-section">
                <h3>Valfri 3D-modell</h3>
                <p>
                  Ladda upp en GLB-fil som föreställer den verkliga möbeln, med alla texturer
                  inbäddade. Högst 20 MB.
                </p>
                {draft.model_url && (
                  <p className="admin-caption">
                    En modell finns sparad.{' '}
                    <button
                      className="admin-text-button"
                      onClick={() => setDraft({ ...draft, model_url: null })}
                    >
                      Ta bort modellen vid nästa sparning
                    </button>
                  </p>
                )}
                <label className="admin-upload">
                  <Plus size={20} />
                  Välj GLB-modell
                  <input
                    type="file"
                    accept=".glb,model/gltf-binary"
                    disabled={busy || !existingProduct}
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      event.target.value = '';
                      if (!file) return;
                      void run(async () => {
                        const url = await uploadAsset(file, 'model');
                        const next = { ...draft, model_url: url };
                        await saveProduct(next, true);
                        setDraft(next);
                        await refresh();
                      }, '3D-modellen är sparad.');
                    }}
                  />
                </label>
              </div>
            </section>
          )}
        </section>
      )}

      {tab === 'restorations' && (
        <section aria-label="Hantera förvandlingar">
          <div className="admin-toolbar">
            <p>Dokumentera samma möbel före och efter.</p>
            <button className="button" onClick={() => setRestorationDraft(emptyRestoration())}>
              <Plus size={17} />
              Ny förvandling
            </button>
          </div>
          <div className="admin-product-list">
            {restorations.map((item) => (
              <article key={item.id}>
                <div className="admin-product-image">
                  <img src={item.after_image_url} alt="" />
                </div>
                <div>
                  <h2>{item.title}</h2>
                  <p>{item.published ? 'Publicerad' : 'Utkast'}</p>
                </div>
                <div className="admin-actions">
                  <button className="admin-text-button" onClick={() => setRestorationDraft(item)}>
                    Redigera
                  </button>
                  <button
                    className="admin-text-button"
                    onClick={() => setDeleteTarget({ kind: 'restoration', id: item.id })}
                  >
                    Ta bort
                  </button>
                </div>
              </article>
            ))}
          </div>
          {!restorations.length && (
            <Empty
              title="Låt förändringen synas."
              text="Använd två riktiga fotografier av samma möbel, tagna ur samma vinkel och med samma bildformat."
            />
          )}
          {restorationDraft && (
            <section className="admin-editor">
              <div className="admin-toolbar">
                <h2>{existingRestoration ? 'Redigera förvandling' : 'Ny förvandling'}</h2>
                <button
                  className="admin-icon-button"
                  aria-label="Stäng redigering"
                  onClick={() => setRestorationDraft(null)}
                  disabled={busy}
                >
                  <X />
                </button>
              </div>
              <form
                className="admin-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  void run(async () => {
                    await saveRestoration(restorationDraft, existingRestoration);
                    await refresh();
                  }, 'Förvandlingen är sparad.');
                }}
              >
                <label>
                  Titel
                  <input
                    required
                    maxLength={150}
                    value={restorationDraft.title}
                    onChange={(event) =>
                      setRestorationDraft({ ...restorationDraft, title: event.target.value })
                    }
                  />
                </label>
                <label>
                  Beskrivning
                  <textarea
                    rows={3}
                    required
                    maxLength={3000}
                    value={restorationDraft.description}
                    onChange={(event) =>
                      setRestorationDraft({ ...restorationDraft, description: event.target.value })
                    }
                  />
                </label>
                <label>
                  Koppla till möbel (valfritt)
                  <select
                    value={restorationDraft.product_id ?? ''}
                    onChange={(event) =>
                      setRestorationDraft({
                        ...restorationDraft,
                        product_id: event.target.value || null,
                      })
                    }
                  >
                    <option value="">Ingen koppling</option>
                    {products.map((product) => (
                      <option key={product.id} value={product.id}>
                        {product.name}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="admin-before-after">
                  {(['before_image_url', 'after_image_url'] as const).map((field, index) => (
                    <div key={field}>
                      {restorationDraft[field] && (
                        <img
                          src={restorationDraft[field]}
                          alt={index === 0 ? 'Före restaurering' : 'Efter restaurering'}
                        />
                      )}
                      <label className="admin-upload">
                        {index === 0 ? 'Välj före-bild' : 'Välj efter-bild'}
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          disabled={busy}
                          onChange={(event) => {
                            const file = event.target.files?.[0];
                            event.target.value = '';
                            if (!file) return;
                            void run(async () => {
                              const url = await uploadAsset(file, 'image');
                              setRestorationDraft((previous) =>
                                previous ? { ...previous, [field]: url } : null,
                              );
                            }, 'Bilden är uppladdad. Spara förvandlingen för att publicera ändringen.');
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </div>
                <label className="admin-checkbox">
                  <input
                    type="checkbox"
                    checked={restorationDraft.published}
                    onChange={(event) =>
                      setRestorationDraft({ ...restorationDraft, published: event.target.checked })
                    }
                  />
                  Publicera i galleriet
                </label>
                <div>
                  <button className="button" disabled={busy}>
                    {busy ? 'Sparar…' : 'Spara förvandling'}
                  </button>
                </div>
              </form>
            </section>
          )}
        </section>
      )}

      {tab === 'orders' && (
        <section>
          <div className="admin-toolbar">
            <p>Senaste 200 beställningarna. Betalningsstatus uppdateras av Stripe.</p>
            <button
              className="admin-text-button"
              disabled={busy}
              onClick={() => void run(refresh, 'Listan är uppdaterad.')}
            >
              Uppdatera
            </button>
          </div>
          {!orders.length ? (
            <Empty
              title="Inga beställningar ännu."
              text="När betalningar är aktiverade visas bekräftade och pågående beställningar här."
            />
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th scope="col">Beställning och möbler</th>
                    <th scope="col">Kund</th>
                    <th scope="col">Summa</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id}>
                      <td>
                        <strong className="admin-order-id">{order.id}</strong>
                        <small>{date(order.created_at)}</small>
                        <small className="admin-reference">
                          {order.payment_reference || 'Ingen betalningsreferens'}
                        </small>
                        {!!order.order_items?.length && (
                          <ul className="admin-order-items">
                            {order.order_items.map((item) => (
                              <li key={item.product_id}>
                                <strong>{item.name}</strong>
                                <small>
                                  {item.quantity} st × {money(item.price)} ={' '}
                                  {money(item.quantity * item.price)}
                                </small>
                              </li>
                            ))}
                          </ul>
                        )}
                      </td>
                      <td>
                        {order.customer_name}
                        <small>{order.customer_email}</small>
                      </td>
                      <td>{money(order.total)}</td>
                      <td>
                        {status[order.status] ?? order.status}
                        {['creating', 'reserved', 'payment_pending'].includes(order.status) && (
                          <small>
                            <button
                              className="admin-text-button"
                              disabled={busy}
                              onClick={() =>
                                void run(async () => {
                                  await reconcileOrder(order.id);
                                  await refresh();
                                }, 'Reservationen är kontrollerad mot Stripe.')
                              }
                            >
                              Kontrollera reservation
                            </button>
                          </small>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {tab === 'messages' && (
        <section>
          <div className="admin-toolbar">
            <p>Senaste 200 kontaktmeddelandena.</p>
            <button
              className="admin-text-button"
              disabled={busy}
              onClick={() => void run(refresh, 'Listan är uppdaterad.')}
            >
              Uppdatera
            </button>
          </div>
          {!messages.length ? (
            <Empty
              title="Här börjar samtalet."
              text="Meddelanden från kontaktformuläret visas här när formuläret är anslutet."
            />
          ) : (
            <div className="admin-message-list">
              {messages.map((message) => (
                <article key={message.id}>
                  <header>
                    <h2>{message.name}</h2>
                    <span>{date(message.created_at)}</span>
                  </header>
                  <a href={`mailto:${encodeURIComponent(message.email)}`}>{message.email}</a>
                  <p>{message.message}</p>
                  {message.product_id && (
                    <Link to={`/mobler/${message.product_id}`} className="admin-text-button">
                      Visa möbeln frågan gäller
                    </Link>
                  )}
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      {tab === 'company' && (
        <section>
          <p className="admin-caption">
            Äkta fotografier av teamet och arbetet visas på sidan Om oss. Publicera bara bilder som
            ni har rätt att använda.
          </p>
          <CompanyUploader
            busy={busy}
            onUpload={(file, alt) =>
              void run(async () => {
                const image_url = await uploadAsset(file, 'image');
                await saveCompanyImage({
                  id: crypto.randomUUID(),
                  image_url,
                  alt,
                  sort_order: companyImages.length,
                  published: true,
                });
                await refresh();
              }, 'Företagsbilden är publicerad.')
            }
          />
          {!companyImages.length && (
            <Empty
              title="Människorna bakom möblerna."
              text="Lägg till ett teamfoto eller en bild från ert arbete när ni är redo."
            />
          )}
          <div className="admin-image-grid company-image-grid">
            {companyImages.map((item) => (
              <figure key={item.id}>
                <img src={item.image_url} alt={item.alt} />
                <figcaption>
                  {item.alt}
                  <button
                    className="admin-text-button"
                    disabled={busy}
                    onClick={() => setDeleteTarget({ kind: 'company', id: item.id })}
                  >
                    Ta bort
                  </button>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>
      )}

      {deleteTarget && (
        <div className="admin-delete-confirm" role="alert">
          <div>
            <strong>Vill du ta bort innehållet?</strong>
            <p>Det tas bort från webbplatsen. Uppladdade originalfiler finns kvar i lagringen.</p>
          </div>
          <button
            className="button"
            disabled={busy}
            onClick={() =>
              void run(async () => {
                if (deleteTarget.kind === 'product') {
                  await deleteProduct(deleteTarget.id);
                  if (draft?.id === deleteTarget.id) setDraft(null);
                } else if (deleteTarget.kind === 'restoration') {
                  await deleteRestoration(deleteTarget.id);
                  if (restorationDraft?.id === deleteTarget.id) setRestorationDraft(null);
                } else await deleteCompanyImage(deleteTarget.id);
                setDeleteTarget(null);
                await refresh();
              }, 'Innehållet är borttaget.')
            }
          >
            Ja, ta bort
          </button>
          <button
            className="button button-outline"
            disabled={busy}
            onClick={() => setDeleteTarget(null)}
          >
            Avbryt
          </button>
        </div>
      )}
      <p className="admin-footnote">
        <ShieldCheck size={16} /> Behörigheter och betalningar kontrolleras av servern.
        Kunduppgifter visas bara för administratörer.
      </p>
    </div>
  );
}

function Empty({ title, text }: { title: string; text: string }) {
  return (
    <div className="admin-empty">
      <h2>{title}</h2>
      <p>{text}</p>
    </div>
  );
}

function CompanyUploader({
  busy,
  onUpload,
}: {
  busy: boolean;
  onUpload: (file: File, alt: string) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [alt, setAlt] = useState('');
  return (
    <form
      className="admin-form admin-company-upload"
      onSubmit={(event) => {
        event.preventDefault();
        if (file && alt.trim()) onUpload(file, alt.trim());
      }}
    >
      <label>
        Beskriv vad bilden visar
        <input
          required
          maxLength={250}
          value={alt}
          onChange={(event) => setAlt(event.target.value)}
          placeholder="Till exempel: Teamet i verkstaden"
        />
      </label>
      <label>
        Fotografi
        <input
          type="file"
          required
          accept="image/jpeg,image/png,image/webp"
          onChange={(event) => setFile(event.target.files?.[0] ?? null)}
        />
      </label>
      <button className="button" disabled={busy || !file}>
        {busy ? 'Laddar upp…' : 'Ladda upp och publicera'}
      </button>
    </form>
  );
}
