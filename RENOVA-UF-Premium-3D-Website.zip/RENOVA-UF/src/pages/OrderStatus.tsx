import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useCart } from '../components/CartProvider';
import { formatPrice } from '../lib/format';
import { saveAttempt } from '../lib/checkoutAttempt';
export default function OrderStatus() {
  const [params] = useSearchParams();
  const { clear } = useCart();
  const [state, setState] = useState<{ status: string; total: number } | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const orderId = params.get('orderId') || '';
  const token = params.get('token') || '';
  const cancelled = params.get('result') === 'cancel';
  const check = useCallback(async () => {
    if (!orderId || !token) {
      setError('Beställningslänken är ofullständig. Kontakta oss om du behöver hjälp.');
      return;
    }
    try {
      const response = await fetch(
        `/api/order-status?orderId=${encodeURIComponent(orderId)}&token=${encodeURIComponent(token)}`,
        { headers: { Accept: 'application/json' }, cache: 'no-store' },
      );
      if (!response.headers.get('content-type')?.includes('application/json'))
        throw new Error('Orderstatus är inte tillgänglig just nu.');
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Status kunde inte hämtas.');
      setState(result);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Status kunde inte hämtas.');
    }
  }, [orderId, token]);
  useEffect(() => {
    void check();
    let count = 0;
    const timer = setInterval(() => {
      if (++count >= 12) {
        clearInterval(timer);
        return;
      }
      void check();
    }, 5000);
    return () => clearInterval(timer);
  }, [check]);
  useEffect(() => {
    if (state?.status === 'paid') {
      clear();
      saveAttempt(null);
    }
    if (['expired', 'cancelled', 'failed'].includes(state?.status || '')) saveAttempt(null);
  }, [state?.status]); // Clear only after a verified server status.
  async function cancel() {
    setBusy(true);
    try {
      const response = await fetch('/api/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, statusToken: token }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Reservationen kunde inte avbrytas.');
      await check();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Försök igen.');
    } finally {
      setBusy(false);
    }
  }
  const paid = state?.status === 'paid';
  const ended = ['expired', 'cancelled', 'failed'].includes(state?.status || '');
  return (
    <section className="container section order-status">
      <span className="eyebrow">Din beställning</span>
      <h1>
        {paid
          ? 'Tack för ditt köp.'
          : ended
            ? 'Reservationen är avslutad.'
            : cancelled
              ? 'Vill du fortsätta senare?'
              : 'Vi inväntar betalningen.'}
      </h1>
      <p>
        {paid
          ? 'Din betalning är bekräftad. Spara ditt ordernummer och kontakta oss för att komma överens om hämtning i Eskilstuna.'
          : ended
            ? 'Ingen ny betalning kan göras för den här reservationen. Se varukorgen för aktuell tillgänglighet.'
            : cancelled
              ? 'Du har återvänt från betalningen. Du kan frigöra möbeln genom att avbryta reservationen nedan.'
              : 'Vi visar bekräftelsen när betalningen har verifierats. Den här sidan är i sig inte ett kvitto på en genomförd betalning.'}
      </p>
      {state && (
        <div className="notice">
          <p>Ordernummer: {orderId}</p>
          <p>Summa: {formatPrice(state.total)}</p>
        </div>
      )}
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      <div className="button-row">
        {!paid && !ended && (
          <button className="button button-outline" onClick={() => void check()}>
            Uppdatera status
          </button>
        )}
        {cancelled && !paid && !ended && (
          <button className="button" disabled={busy} onClick={() => void cancel()}>
            {busy ? 'Avbryter…' : 'Avbryt reservationen'}
          </button>
        )}
        <Link className="text-link" to={paid ? '/kontakt' : '/varukorg'}>
          {paid ? 'Kontakta oss om hämtning' : 'Till varukorgen'}
        </Link>
      </div>
    </section>
  );
}
