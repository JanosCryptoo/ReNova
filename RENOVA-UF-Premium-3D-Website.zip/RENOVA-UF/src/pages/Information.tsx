import { Link } from 'react-router-dom';
export function Privacy() {
  return (
    <article className="container prose-page">
      <span className="eyebrow">Din integritet</span>
      <h1>
        Med respekt
        <br />
        <em>för dina uppgifter.</em>
      </h1>
      <h2>Det här används på webbplatsen</h2>
      <p>
        Varukorgen sparas lokalt i din webbläsare så att möblerna finns kvar när du återvänder. Ett
        påbörjat betalningsförsök med namn och e-post sparas tillfälligt i den öppna fliken, så att
        det kan återupptas efter ett avbrott. Det tas bort när ordern bekräftats eller avbrutits. Vi
        använder inga analysverktyg eller reklamkakor i den här versionen.
      </p>
      <h2>När du kontaktar oss</h2>
      <p>
        Om kontaktformuläret är aktiverat använder RENOVA UF ditt namn, din e-postadress och ditt
        meddelande för att besvara din fråga. Skicka inte känsliga personuppgifter.
      </p>
      <h2>När du handlar</h2>
      <p>
        Vid ett köp används kontakt- och orderuppgifter för att hantera beställningen och komma
        överens om hämtning. Kortuppgifter hanteras av Stripe och sparas inte av webbplatsen.
        Supabase kan användas för lagring av produkt-, kontakt- och orderuppgifter. Cloudflare
        levererar webbplatsen och kan utföra säkerhetskontroller.
      </p>
      <h2>Externa länkar</h2>
      <p>
        Instagram öppnas först när du följer en länk dit. Ingen inbäddad Instagram-spårning laddas
        här.
      </p>
      <h2>Frågor om dina uppgifter</h2>
      <p>
        Kontakta RENOVA UF via{' '}
        <a href="https://www.instagram.com/uf_renova/" target="_blank" rel="noopener noreferrer">
          @uf_renova
        </a>{' '}
        för frågor om hur dina uppgifter används, eller om du vill begära tillgång, rättelse eller
        radering.
      </p>
      <p className="notice">
        Innan köp och kontaktformulär öppnas kompletteras informationen med ansvarig kontakt,
        rättsliga grunder och lagringstider.
      </p>
      <Link className="text-link" to="/kontakt">
        Till kontakt
      </Link>
    </article>
  );
}
export function PurchaseInfo() {
  return (
    <article className="container prose-page">
      <span className="eyebrow">Bra att veta</span>
      <h1>
        Ett genomtänkt
        <br />
        <em>köp.</em>
      </h1>
      <h2>Unika, begagnade möbler</h2>
      <p>
        Våra möbler är begagnade och kan bära spår av tidigare användning. På respektive produktsida
        hittar du beskrivning, skick, mått och pris i svenska kronor.
      </p>
      <h2>Tillgänglighet</h2>
      <p>
        En möbel i varukorgen är inte reserverad. När en betalning startas kontrolleras pris och
        tillgänglighet igen och möbeln reserveras under betalningen. En beställning bekräftas först
        när betalningen har verifierats.
      </p>
      <h2>Hämtning</h2>
      <p>
        Den här butiken är förberedd för hämtning i Eskilstuna efter överenskommelse. Ingen
        leveranstjänst eller fraktavgift är aktiverad. Kontakta oss för att planera hämtningen.
      </p>
      <h2>Betalning</h2>
      <p>
        När onlinebetalning är öppnad slutför du ditt köp hos Stripe. Tillgängliga betalsätt visas
        där. Swish visas endast om det stöds och har aktiverats för verksamheten.
      </p>
      <h2>Frågor om ett köp</h2>
      <p>
        Hör av dig via <Link to="/kontakt">kontaktsidan</Link> eller Instagram om en produkt eller
        beställning. Spara ditt ordernummer vid ett genomfört köp.
      </p>
      <p className="notice">
        Webbköp är ännu inte öppnade. Före öppning behöver RENOVA UF publicera fullständiga
        köpvillkor, säljaruppgifter och information om ångerrätt och reklamation.
      </p>
      <Link className="button button-outline" to="/mobler">
        Till våra möbler
      </Link>
    </article>
  );
}
export function NotFound() {
  return (
    <section className="container section centered">
      <span className="eyebrow">Sidan finns inte</span>
      <h1>
        Ett litet
        <br />
        <em>sidospår.</em>
      </h1>
      <p>Den här adressen leder inte till någon sida hos oss.</p>
      <Link className="button" to="/">
        Till startsidan
      </Link>
    </section>
  );
}
