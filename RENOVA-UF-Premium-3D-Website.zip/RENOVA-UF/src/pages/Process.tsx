import { lazy, Suspense } from 'react';
import { Link } from 'react-router-dom';
import { Search, Hammer, Leaf, Heart } from 'lucide-react';
import { Reveal } from '../components/animations/Reveal';
const RestorationExperience = lazy(() => import('../components/three/RestorationExperience'));
const steps = [
  {
    title: 'Hitta',
    quote: 'Vi köper in begagnade och slitna möbler.',
    body: 'Allt börjar med att se potentialen. Vi letar efter former, material och detaljer som förtjänar att bevaras, även när ytan har sett bättre dagar.',
    icon: Search,
    word: 'Potential.',
  },
  {
    title: 'Förnya',
    quote: 'Vi rengör, reparerar och fräschar upp möblerna.',
    body: 'Varje möbel har olika behov. Vi tar hand om den med respekt för dess material och karaktär. Det handlar om att lyfta fram det som redan gör möbeln speciell.',
    icon: Hammer,
    word: 'Omsorg.',
  },
  {
    title: 'Ge nytt liv',
    quote: 'Istället för att möblerna slängs får de en ny chans och längre livslängd.',
    body: 'Vi tror på att använda det som redan finns. När en möbel får leva vidare kan dess berättelse fortsätta i en ny miljö.',
    icon: Leaf,
    word: 'Förvandling.',
  },
  {
    title: 'Sälj vidare',
    quote: 'Vi säljer de uppfräschade möblerna till ett överkomligt pris.',
    body: 'En genomtänkt möbel ska kunna få plats i fler hem. Vi presenterar skick, mått och detaljer så att du kan hitta en möbel som passar dig.',
    icon: Heart,
    word: 'Ett nytt hem.',
  },
];
export default function Process() {
  return (
    <>
      <div className="container">
        <Reveal className="page-intro">
          <span className="eyebrow">Vår process</span>
          <h1>
            Vi börjar inte om.
            <br />
            <em>Vi tar vid.</em>
          </h1>
          <p>
            Bakom varje förnyad möbel finns omtanke. Från det första fyndet till dess nästa plats i
            vardagen.
          </p>
        </Reveal>
      </div>
      <div className="process-chapters">
        {steps.map((s, i) => (
          <section className={`process-chapter chapter-${i + 1}`} key={s.title}>
            <div className="container chapter-grid">
              <Reveal className="chapter-art">
                <s.icon strokeWidth={0.55} />
                <span>{s.word}</span>
              </Reveal>
              <Reveal className="chapter-copy">
                <span className="eyebrow">
                  0{i + 1} — {s.title.toLocaleUpperCase('sv')}
                </span>
                <h2>{s.quote}</h2>
                <p>{s.body}</p>
              </Reveal>
            </div>
          </section>
        ))}
      </div>
      <Suspense fallback={<p className="container">Förvandlingen tar form…</p>}>
        <RestorationExperience />
      </Suspense>
      <section className="container section centered">
        <span className="eyebrow">Nästa steg</span>
        <h2>
          Kanske väntar din
          <br />
          <em>nästa favorit här.</em>
        </h2>
        <Link to="/mobler" className="button">
          Utforska våra möbler
        </Link>
      </section>
    </>
  );
}
