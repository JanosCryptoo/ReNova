import { lazy, Suspense, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Armchair, Check, Rotate3d } from 'lucide-react';
import type { Product } from '../types';
import { getProduct } from '../services/catalog';
import { useCart } from '../components/CartProvider';
import { formatPrice, safeImageUrl } from '../lib/format';
const ChairScene = lazy(() => import('../components/three/ChairScene'));
export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState(0);
  const [model, setModel] = useState(false);
  const { add } = useCart();
  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setActive(0);
    setModel(false);
    setError('');
    getProduct(id || '')
      .then((p) => {
        if (mounted) setProduct(p);
      })
      .catch(() => {
        if (mounted) setError('Möbeln kunde inte hämtas just nu. Försök igen senare.');
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [id]);
  if (loading)
    return (
      <div className="container section" role="status">
        Hämtar möbeln…
      </div>
    );
  if (!product)
    return (
      <div className="container section">
        <h1>{error ? 'Något gick fel.' : 'Möbeln finns inte här.'}</h1>
        <p>{error || 'Den kan ha tagits bort eller ännu inte publicerats.'}</p>
        <Link to="/mobler" className="button">
          Till våra möbler
        </Link>
      </div>
    );
  const available = product.stock > 0 && product.availability === 'available';
  return (
    <div className="container product-detail">
      <nav className="breadcrumbs" aria-label="Brödsmulor">
        <Link to="/mobler">Våra möbler</Link>
        <span>/</span>
        <span>{product.name}</span>
      </nav>
      <div className="product-detail-grid">
        <div>
          <div className="product-main-image">
            {model && product.model_url ? (
              <Suspense fallback={<p>Laddar 3D-modellen…</p>}>
                <ChairScene modelUrl={product.model_url} />
              </Suspense>
            ) : product.product_images.length ? (
              <img
                src={safeImageUrl(product.product_images[active]?.image_url)}
                alt={`${product.name}, bild ${active + 1}`}
              />
            ) : (
              <div className="product-no-image">
                <Armchair size={96} strokeWidth={0.6} />
                <span>Fotografi kommer</span>
              </div>
            )}
          </div>
          <div className="product-thumbnails">
            {product.product_images.map((img, i) => (
              <button
                key={img.id || img.image_url}
                aria-label={`Visa bild ${i + 1}`}
                aria-pressed={active === i && !model}
                onClick={() => {
                  setActive(i);
                  setModel(false);
                }}
              >
                <img src={safeImageUrl(img.image_url)} alt="" />
              </button>
            ))}
            {product.model_url && (
              <button
                className="model-toggle"
                aria-pressed={model}
                onClick={() => setModel(!model)}
              >
                <Rotate3d size={24} />
                Visa i 3D
              </button>
            )}
          </div>
        </div>
        <div className="product-detail-copy">
          <span className="eyebrow">{product.category} · Omsorgsfullt förnyad</span>
          <h1>{product.name}</h1>
          <p className="product-price">{formatPrice(product.price)}</p>
          <p className="product-description">{product.description}</p>
          <span className="availability">
            <Check size={16} />
            {available
              ? 'Tillgänglig — ett unikt exemplar'
              : product.availability === 'reserved'
                ? 'Reserverad just nu'
                : 'Såld'}
          </span>
          <button className="button full-width" onClick={() => add(product)} disabled={!available}>
            {available ? 'Lägg i varukorgen' : 'Inte tillgänglig'}
          </button>
          <Link className="text-link" to={`/kontakt?produkt=${product.id}`}>
            Fråga oss om möbeln
          </Link>
          <dl className="product-facts">
            <div>
              <dt>Skick</dt>
              <dd>{product.condition}</dd>
            </div>
            <div>
              <dt>Mått</dt>
              <dd>{product.dimensions}</dd>
            </div>
            <div>
              <dt>Hämtning</dt>
              <dd>Eskilstuna, efter överenskommelse</dd>
            </div>
          </dl>
          <p className="small-copy">
            Begagnade möbler bär spår av sitt tidigare liv. Läs beskrivningen och titta på bilderna
            före köp.
          </p>
        </div>
      </div>
    </div>
  );
}
