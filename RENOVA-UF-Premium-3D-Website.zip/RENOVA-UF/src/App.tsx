import { lazy, Suspense, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { MotionConfig } from 'motion/react';
import { CartProvider } from './components/CartProvider';
import Layout from './components/layout/Layout';
import MotionSystem from './components/animations/MotionSystem';
import MagneticButtons from './components/animations/MagneticButtons';
import Home from './pages/Home';
const Products = lazy(() => import('./pages/Products'));
const ProductDetail = lazy(() => import('./pages/ProductDetail'));
const Process = lazy(() => import('./pages/Process'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const Cart = lazy(() => import('./pages/Cart'));
const Admin = lazy(() => import('./pages/Admin'));
const OrderStatus = lazy(() => import('./pages/OrderStatus'));
const Privacy = lazy(() => import('./pages/Information').then((m) => ({ default: m.Privacy })));
const PurchaseInfo = lazy(() =>
  import('./pages/Information').then((m) => ({ default: m.PurchaseInfo })),
);
const NotFound = lazy(() => import('./pages/Information').then((m) => ({ default: m.NotFound })));
const titles: Record<string, string> = {
  '/': 'Från gammalt till nytt.',
  '/mobler': 'Våra möbler',
  '/process': 'Vår process',
  '/om-oss': 'Om oss',
  '/kontakt': 'Kontakt',
  '/varukorg': 'Varukorg',
  '/admin': 'Administration',
  '/integritet': 'Integritet',
  '/kopinformation': 'Köpinformation',
  '/bestallning': 'Din beställning',
};
export default function App() {
  const { pathname } = useLocation();
  useEffect(() => {
    document.title = `${titles[pathname] || 'Möbler med historia'} — RENOVA UF`;
  }, [pathname]);
  return (
    <MotionConfig reducedMotion="user">
      <CartProvider>
        <MotionSystem />
        <MagneticButtons />
        <Suspense
          fallback={
            <div className="page-loading" role="status">
              Ett nytt kapitel tar form…
            </div>
          }
        >
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="mobler" element={<Products />} />
              <Route path="mobler/:id" element={<ProductDetail />} />
              <Route path="process" element={<Process />} />
              <Route path="om-oss" element={<About />} />
              <Route path="kontakt" element={<Contact />} />
              <Route path="varukorg" element={<Cart />} />
              <Route path="admin" element={<Admin />} />
              <Route path="bestallning" element={<OrderStatus />} />
              <Route path="integritet" element={<Privacy />} />
              <Route path="kopinformation" element={<PurchaseInfo />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Suspense>
      </CartProvider>
    </MotionConfig>
  );
}
